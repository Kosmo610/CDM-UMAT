# LTH_CJ2 — 사이클 동결의 원인이 밝혀졌습니다. 그 수정판입니다

압축을 `E:\LTH\` 에 풀면 `E:\LTH\LTH_CJ2_0812_1411\` 이 됩니다.

```
E:
cd \LTH\LTH_CJ2_0812_1411
```

**폴더 이름을 바꾸셨으면 `cd` 줄만 고치세요.**

---

## 진단: `*Temperature` 매핑은 무죄였습니다

`LTH_CJ5_stepdiag.csv` 가 결정적이었습니다:

```
Quench-end NT mean: 898 898 898 898
Reheat-end NT mean: 899 899 899 899
```

**1사이클 뒤에 멈춘 것이 아니라, 처음부터 온도가 흔들린 적이 없습니다.**
900 °C 판이 900 °C 에 그대로 있었습니다.

원인은 `LTH_CJHEAT` 가 **1000배 틀린 열카드**로 돌았다는 것입니다
(`*Conductivity 0.015, 0.015, 0.004` — 2026-08-11에 고친 바로 그 값):

| | 값 |
|---|---|
| 그 카드의 열확산율 | 0.0019 mm²/s (정상은 1.23~3.98) |
| 그래서 냉각 시상수 | **15 829 초** |
| 30초 급랭이 낸 온도차 | **1.14 K** → 900 → 898.9 °C |
| odb가 적은 값 | **898.9 → 898** ✔ |

**예측과 관측이 1 K 안에서 일치합니다.** 손상 구동력이 없으니 $d_{cyc}$ 도
자라지 않았고, CJ5/CJ1 이 **정확히 5.000** 이던 것도 이것으로 설명됩니다 —
매 사이클이 똑같이 0이므로 5배 하면 정확히 5배입니다.

## `compare_cyclejump.py` 의 400 % 도 고쳤습니다

그 출력은 **자기모순**이었습니다 — `dcyc` 행에 400.002 %를 찍고 세 줄 아래에
`OK: 0.00 %` 라고 했습니다. 둘 다 각자 맞는 말이었고 합쳐서 무의미했습니다.

- $d_{cyc}$ 가 바닥(1e-4) 아래면 **비율을 아예 계산하지 않습니다** (`--` 로 표시).
- 그리고 **양쪽 다 바닥 아래면 판정이 `VOID`** 입니다 — "아무 일도 일어나지
  않은 해석으로 점프를 승인"하는 일이 다시는 없습니다.

---

# ① 실행

## A. 열 잡 3개 — 전부 병렬, 잡당 수 분

**`user=` 붙이지 마세요.** 순수 열전도입니다.

창 1
```
abaqus job=LTH_CJ2_HEAT_SL input=LTH_CJ2_HEAT_SL.inp double interactive cpus=2 memory="20gb"
```
창 2
```
abaqus job=LTH_CJ2_HEAT_SM input=LTH_CJ2_HEAT_SM.inp double interactive cpus=2 memory="20gb"
```
창 3
```
abaqus job=LTH_CJ2_HEAT_SH input=LTH_CJ2_HEAT_SH.inp double interactive cpus=2 memory="20gb"
```

> **왜 열 잡을 또 돌리나 — 카드가 바뀌었습니다.** a1이 제 질문(a2-0027)에
> 판정을 내려, $k(T)$ 형상을 refs/[20]에서 빌리던 것을 **우리 구성재에서
> 유도한 것**으로 바꿨습니다. 빌린 형상은 900 °C에서 $Bi$를 23.9 % 부풀려
> **우리에게 유리한 쪽으로** 틀려 있었습니다. 1000 °C에서 $\bar k_3$ 가
> 3.57 → 4.59 (+28.6 %)로 바뀌므로, 어제 받은 구배 사다리(7.0 / 36.9 / 72.2 %)는
> **잠정값**이고 이 세 잡이 최종값을 냅니다. 몇 분이면 끝납니다.

## B. 사이클 점프 쌍 — **`LTH_CJ2_HEAT_SM.odb` 가 나온 뒤**

두 잡은 **같은 열 odb를 읽습니다**(열 스텝 1·2만 읽으므로 공유가 안전합니다).
서로 독립이므로 **병렬**입니다.

창 4
```
abaqus job=LTH_CJ2_EXP input=LTH_CJ2_EXP.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```
창 5
```
abaqus job=LTH_CJ2_JMP input=LTH_CJ2_JMP.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```

- `EXP` = 명시적, 20 사이클 전부 계산 (43 스텝). `JMP` = 점프 5, 4 사이클만
  계산해 20을 대표 (11 스텝). **둘 다 N=20에 도달합니다.**
- EXP가 JMP보다 4배쯤 오래 걸립니다 — 그게 점프가 사려는 시간입니다.

# ② 완료 후

## 열 잡 (ODB → `abaqus python`)
```
abaqus python extract_thermal_profile.py LTH_CJ2_HEAT_SL.odb LTH_CJ2_HEAT_SM.odb LTH_CJ2_HEAT_SH.odb
```
→ **`thermal_summary.csv`** — 이번엔 `alpha_verdict` 가 `consistent` 로 나와야
합니다(어제의 `CARD_MISMATCH` 는 판독기 결함이었고 고쳤습니다).

## 사이클 점프 (ODB → `abaqus python`, 그 다음 일반 `python`)
```
abaqus python extract_probe.py LTH_CJ2_EXP.odb
abaqus python extract_probe.py LTH_CJ2_JMP.odb
python compare_cyclejump.py LTH_CJ2_EXP_EN.csv LTH_CJ2_JMP_EN.csv
```
→ **`cyclejump_summary.csv`**

**먼저 `LTH_CJ2_EXP_stepdiag.csv` 를 보세요.** Quench-end NT 평균이 300 근처,
Reheat-end 가 900 근처로 **번갈아** 나와야 합니다. 898/899 처럼 붙어 있으면
또 온도가 안 흔들린 것이고, 그때는 `compare_cyclejump` 를 돌릴 필요가 없습니다
(이제 `VOID` 라고 말해 줍니다).

# ③ 올려주실 파일

| 파일 | 언제 |
|---|---|
| **`thermal_summary.csv`** | 열 잡 3개 뒤 |
| **`LTH_CJ2_EXP_stepdiag.csv`** | 역학 잡 뒤 — **온도가 흔들렸는지의 증거** |
| **`cyclejump_summary.csv`** | stepdiag가 정상일 때만 |

# 파일 목록

| 파일 | 무엇 | 실행기 |
|---|---|---|
| `LTH_CJ2_HEAT_SL/SM/SH.inp` | 과도 열전달, **a1 판정 반영 카드** | UMAT 불필요 |
| `LTH_CJ2_EXP.inp` | 사이클 점프 1 (명시적 20 사이클) | UMAT 필요 |
| `LTH_CJ2_JMP.inp` | 사이클 점프 5 (4 사이클로 20 대표) | UMAT 필요 |
| `extract_thermal_profile.py` | 구배·경계층·열확산율 | `abaqus python` |
| `extract_probe.py` | E(N) + stepdiag | `abaqus python` |
| `compare_cyclejump.py` | 점프 오차 (바닥 아래면 VOID) | 일반 `python` |
