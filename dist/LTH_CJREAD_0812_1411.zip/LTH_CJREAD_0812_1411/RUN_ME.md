# LTH_CJREAD — 사이클 잡을 다시 **읽기만** 합니다 (해석 재실행 없음, 수 초)

## ★ 해석은 다시 돌리지 않습니다

`LTH_CJ1.odb` 와 `LTH_CJ5.odb` 는 **이미 있습니다.** 이 묶음은 그 두 odb를
읽는 스크립트 4개뿐입니다. 몇 시간짜리 해석을 다시 돌릴 필요가 전혀 없습니다.

## 어디에 풀어야 하나 — **기존 폴더에 덮어쓰기**

파일 4개를 **`E:\LTH\LTH_CJFIX_0810_1021\` 안에 덮어쓰세요.**
(odb가 그 폴더에 있고, 스크립트는 자기 옆의 odb를 읽습니다.)

덮어쓸 파일:

```
extract_probe.py
compare_cyclejump.py
damage_map.py
damage_census.py
```

## 무엇을 알아내려는 것인가

CJ5 / CJ1 의 최종 `d_cyc` 비가 **정확히 5.000** 으로 나왔습니다. cycle jump가
정말 작동한 것이라면 이 값은 5에 *가깝되* 정확히 5는 아니어야 합니다.
정확히 5라는 것은 **손상이 Quench_1 이후 얼어붙고 사이클 수만 곱해졌다**는
뜻일 수 있습니다. 유력한 용의자는 `*Temperature, file=` 이 2번째 사이클부터
온도를 다시 읽지 못하는 것입니다 — Abaqus는 이때 **조용히 초기 온도를 유지**
하며, 그러면 완벽하게 수렴한 채로 아무 일도 일어나지 않습니다.

`extract_probe.py` 가 이제 `<잡이름>_stepdiag.csv` 를 씁니다. 스텝마다 NT의
최소·평균·최대를 적으므로, **온도가 실제로 사이클을 돌았는지가 그 표에서
바로 보입니다.** 2번째 사이클부터 NT가 움직이지 않으면 용의자가 확정됩니다.

---

# 실행 명령 (전부 `abaqus python` — odb를 읽습니다)

```
E:
cd \LTH\LTH_CJFIX_0810_1021
abaqus python extract_probe.py LTH_CJ1.odb
abaqus python extract_probe.py LTH_CJ5.odb
```

→ `LTH_CJ1_EN.csv`, `LTH_CJ1_stepdiag.csv`, `LTH_CJ5_EN.csv`, `LTH_CJ5_stepdiag.csv`

**그 다음** (위 4개가 나온 뒤에):

```
python compare_cyclejump.py LTH_CJ1_EN.csv LTH_CJ5_EN.csv
```

→ `cyclejump_summary.csv` — cycle jump 오차 판정. **온도가 실제로 사이클을
돌았을 때만 의미가 있으므로**, stepdiag가 먼저입니다.

# 올려주실 파일 (4개, 또는 5개)

| 파일 | 언제 |
|---|---|
| **`LTH_CJ1_EN.csv`** | 항상 |
| **`LTH_CJ1_stepdiag.csv`** | 항상 — **이게 범인을 정합니다** |
| **`LTH_CJ5_EN.csv`** | 항상 |
| **`LTH_CJ5_stepdiag.csv`** | 항상 |
| `cyclejump_summary.csv` | stepdiag가 정상일 때만 |
