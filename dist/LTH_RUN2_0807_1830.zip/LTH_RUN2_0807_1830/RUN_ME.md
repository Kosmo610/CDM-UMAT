# LTH_RUN2 — 열전도 재실행 (덱 버그 수정) + CJHEAT 진단

압축을 `E:\LTH\` 에 풀면 `E:\LTH\LTH_RUN2_0807_1830\` 이 됩니다.
명령창을 열면 먼저:

```
E:
cd \LTH\LTH_RUN2_0807_1830
```

---

## 왜 다시 돌리나 — 1차 결과에 물리적으로 불가능한 값이 있었다

1차에서 `kbar2 = 56.27 W/(m·K)` 가 나왔습니다. **이 셀에서 가장 잘 전도하는
상(SiC 기지)이 25**이므로, 어떤 미세구조로도 나올 수 없는 값입니다
(병렬 상한 16.39). 원인은 덱입니다 — **`*Boundary` 에 `op=NEW` 가 없어서
앞 스텝의 온도 경계조건이 그대로 남았습니다.**

| 스텝 | 실제로 풀린 것 | 1차 결과 |
|---|---|---|
| dir1 (x) | x 기울기만 | **kbar1 = 15.47 — 유효** |
| dir2 (y) | x + y 동시 | kbar2 무효 |
| dir3 (z) | x + y + z 동시 | **kbar3 무효** |

kbar3가 무효라는 것이 뼈아픕니다 — **공극률 판정이 그 값 위에 서 있었습니다.**
그래서 1차의 "45.7 %, CONSISTENT" 결론은 **철회**합니다.

수정은 스텝 경계조건 3줄뿐입니다. 메시·재료·물성은 **한 글자도 안 바꿨습니다**
(모델 데이터의 `MasterNode` 고정은 그대로 두었습니다 — 거기엔 `op=NEW` 를
쓰면 안 됩니다).

---

# ① 실행 — **4잡 전부 병렬.** 창 4개

각 수 분입니다. UMAT 불필요.

창 1:
```
abaqus job=LTH2_COND_P00 input=LTH2_COND_P00.inp double interactive cpus=2 memory="20gb"
```
창 2:
```
abaqus job=LTH2_COND_P05 input=LTH2_COND_P05.inp double interactive cpus=2 memory="20gb"
```
창 3:
```
abaqus job=LTH2_COND_P32 input=LTH2_COND_P32.inp double interactive cpus=2 memory="20gb"
```
창 4:
```
abaqus job=LTH2_COND_P32K60 input=LTH2_COND_P32K60.inp double interactive cpus=2 memory="20gb"
```

# ② 완료 후 — **CSV가 나옵니다. 그 파일을 보내주세요**

```
abaqus python extract_kbar.py LTH2_COND_P00.odb LTH2_COND_P05.odb LTH2_COND_P32.odb LTH2_COND_P32K60.odb
```

→ **`kbar_summary.csv`** 가 같은 폴더에 생깁니다. **화면 캡처 대신 이 파일을
채팅에 올려 주세요.** 값·상한·판정(yes/NO)이 한 행에 같이 들어 있어서
제가 그 자리에서 다시 계산해 확인할 수 있습니다.

이번에는 **CHECK 0** 이 새로 붙었습니다 — 모든 kbar를 병렬 상한과 대조해
**불가능한 값이면 그 자리에서 잡습니다.** 1차에 이 검사가 있었다면 결과를
믿기 전에 걸렸을 것입니다.

---

# ③ CJHEAT — 아직 못 고쳤습니다. 에러 문구가 필요합니다

같은 폴더에 `LTH_CJHEAT.inp` 를 다시 넣어 두었습니다(1차와 동일).
**아직 원인을 못 찾았습니다.** 덱을 정적으로 훑어봤지만 문법·행 길이·연결성에
잘못이 안 보입니다.

한 번만 더 돌려 주시고:
```
abaqus job=LTH_CJHEAT input=LTH_CJHEAT.inp double interactive cpus=2 memory="8gb"
```

죽으면 **에러 문구를 파일로** 뽑아 주세요 (이것도 캡처 말고 파일로):
```
findstr /I "ERROR" LTH_CJHEAT.dat > CJHEAT_error.txt
```
`CJHEAT_error.txt` 가 비어 있으면:
```
type LTH_CJHEAT.dat > CJHEAT_dat.txt
```
둘 중 나온 파일을 올려 주시면 됩니다.

**CJ1·CJ5 는 이것이 성공해야 돌 수 있으므로 그때까지 대기입니다.**
(파일은 같이 들어 있습니다.)

---

# 파일 목록

| 파일 | 무엇 | 상태 |
|---|---|---|
| `LTH2_COND_P00.inp` | 기지 공극률 0 % | **수정본 — 돌리세요** |
| `LTH2_COND_P05.inp` | 4.5 % | **수정본 — 돌리세요** |
| `LTH2_COND_P32.inp` | 32.4 % | **수정본 — 돌리세요** |
| `LTH2_COND_P32K60.inp` | 32.4 % + 얀 k=50.2 | **수정본 — 돌리세요** |
| `extract_kbar.py` | 판독 + **CSV 출력** — `abaqus python` | 갱신 |
| `LTH_CJHEAT.inp` | 열전달 | 진단용 재시도 |
| `LTH_CJ1.inp` / `LTH_CJ5.inp` | 사이클점프 쌍 | CJHEAT 이후 대기 |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT | CJ1·CJ5용 |
| `extract_probe.py` / `compare_cyclejump.py` | 사이클점프 후처리 | 대기 |

> 1차 결과 파일(`LTH_COND_*.odb` 등)은 **지우지 마세요.** 수정 전후를 대조하면
> "경계조건이 남아서 생긴 차이"를 그림으로 보일 수 있어 논문 부록감입니다.
