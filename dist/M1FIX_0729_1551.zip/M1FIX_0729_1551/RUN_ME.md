# M1FIX — 0729_1551

7월 28일 M1 3잡이 전부 죽은 원인 분석과 수정본입니다.
자세한 원인은 같이 들어있는 `M1_FAILURE_ANALYSIS.md`.

**메시는 한 바이트도 안 바뀌었습니다.** 재료 카드 상수와 스텝 키워드만 바꿨습니다.
UMAT도 그대로입니다 (V1_0 동결 유지).

---

## 0. 먼저 — 공짜로 얻는 정보 (해석 안 돌립니다, 10초)

어제 죽은 잡들의 `.odb`에는 **냉각 스텝이 끝까지 들어있습니다.**
이걸 먼저 읽으세요. 새 해석을 기다릴 필요가 없습니다.

```
abaqus python postprocess/damage_census.py ZHANG2022_c26k_RT23.odb
```
```
abaqus python postprocess/damage_census.py ZHANG2022_c26k_T500.odb
```
```
abaqus python postprocess/damage_census.py ZHANG2022_c26k_T1000.odb
```

화면에 나오는 것 중 **이 세 줄을 저에게 보내주세요**:

- `Matrix` 의 `SDV3 RMT` **mean** 값 → 제 예측은 **0.97** 입니다
- `Matrix` 의 volume-averaged `S11 / S22` → 제 예측은 **약 +302 MPa**,
  XRD 측정치(refs/[15])는 **+114.7 MPa** 입니다
- `Matrix` 의 `SDV1 DMT` 의 `d>=0.9` 부피 비율

이 세 개로 "재료 물성이 틀린 건지, 솔버가 못 따라간 건지"가 갈립니다.

---

## ① 해석 실행 명령 — Abaqus Command 창 **4개**를 여세요

네 잡은 서로 완전히 독립입니다. **순차로 돌리지 마세요.**
32코어 / 256 GB 기준으로 잡당 8코어 · 55 GB로 나눴습니다 (합계 32코어, 220 GB).

**창 1**
```
abaqus job=M1FIX_c26k_RT23 input=M1FIX_c26k_RT23.inp user=UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="55gb"
```

**창 2**
```
abaqus job=M1FIX_c26k_T500 input=M1FIX_c26k_T500.inp user=UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="55gb"
```

**창 3**
```
abaqus job=M1FIX_c26k_T1000 input=M1FIX_c26k_T1000.inp user=UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="55gb"
```

**창 4 — 보험용 (물성 가정이 다릅니다, 아래 §3 읽어주세요)**
```
abaqus job=M1FIX_c26k_RT23_z600 input=M1FIX_c26k_RT23_z600.inp user=UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="55gb"
```

> 이번엔 **빨리 죽게** 만들어놨습니다. 최소 증분을 1e-12 → 1e-8 로,
> 컷백 허용을 20 → 8 로 줄였습니다. 어제는 죽는 데만 23분을 썼는데,
> 이제 안 되면 2~3분 안에 끝납니다. **일찍 죽어도 정상입니다** — 바로 알려주세요.

---

## ② 해석 완료 후 명령

### (a) 응력–변형률 CSV — **`abaqus python`**

잡 하나가 끝날 때마다 바로 돌리세요. 셋 다 기다릴 필요 없습니다.

```
abaqus python postprocess/extract_ss_curve.py M1FIX_c26k_RT23.odb
```
```
abaqus python postprocess/extract_ss_curve.py M1FIX_c26k_T500.odb
```
```
abaqus python postprocess/extract_ss_curve.py M1FIX_c26k_T1000.odb
```
```
abaqus python postprocess/extract_ss_curve.py M1FIX_c26k_RT23_z600.odb
```

→ `M1FIX_c26k_RT23_ss.csv` 등이 나오고, 마지막 줄에
`ULTIMATE STRESS = ___ MPa` 가 찍힙니다.
**이 숫자를 Zhang Table 3(128.45 / 179.42 / 199.15 MPa)과 비교합니다.**

### (b) 손상 상태 점검 — **`abaqus python`** (중요)

```
abaqus python postprocess/damage_census.py M1FIX_c26k_RT23.odb
```
```
abaqus python postprocess/damage_census.py M1FIX_c26k_T500.odb
```

죽었든 끝났든 상관없이 돌아갑니다. 죽었으면 **어디까지 갔는지**가 나옵니다.

### (c) 그림 — **`python3`** (`abaqus python` 아닙니다, matplotlib 필요)

3개가 다 끝난 뒤에만 의미가 있습니다.

```
python3 postprocess/plot_compare.py M1FIX_c26k_RT23_ss.csv M1FIX_c26k_T500_ss.csv M1FIX_c26k_T1000_ss.csv
```

→ `ss_curves_by_temperature.png`

### (d) 인공 감쇠 검사 — **이번에 새로 생긴 필수 절차**

이번 덱에는 `*Static, stabilize=2e-4` 를 넣었습니다. 수렴을 돕는 **인공 감쇠**입니다.
공짜가 아닙니다 — 너무 많이 먹으면 **피크 응력이 가짜로 올라갑니다.**

Abaqus/CAE에서 XY Data → ODB history output → `ALLSD`, `ALLIE` 를 띄우고

> **ALLSD / ALLIE < 0.05 (5 %)**

인지 확인하세요. 넘으면 `stabilize` 값을 낮춰서 다시 돌려야 합니다.
**넘었는지 아닌지 꼭 알려주세요.** 안 넘었으면 결과를 논문에 그대로 쓸 수 있습니다.

---

## ③ 창 4번(`_z600`)이 뭔지 — 이건 물성 가정이 다릅니다

창 1~3은 **수치 설정만** 고친 것입니다. 물성은 어제와 똑같습니다.

창 4는 `*Expansion, zero=` 를 **1050 °C → 600 °C** 로 내린 것입니다.
즉 "SiC가 1050 °C에서부터 응력을 쌓기 시작한다"가 아니라
"600 °C 아래에서부터 쌓기 시작한다(그 위에서는 완화된다)"는 가정입니다.

**왜 이걸 같이 돌리나:**

| `zero=` | 계산된 매트릭스 잔류응력 | r = σ/X_t |
|---|---|---|
| **1050 (지금)** | **302 MPa** | **0.973** ← 손상 문턱의 97 % |
| 800 | 270 | 0.871 |
| **600 (창 4)** | **233** | **0.751** |
| 307 | **114.7** ← XRD 측정치 | 0.370 |

지금 덱은 냉각만으로 매트릭스를 **손상 문턱의 97 %**까지 밀어붙입니다.
여유가 3 % 밖에 없으니, 인장을 조금만 걸어도 바로 연화 구간으로 들어갑니다.
그리고 문헌(refs/[15])의 XRD 실측 잔류응력은 **114.7 MPa** — 우리 값의 **1/2.6** 입니다.

**이건 제가 마음대로 정할 문제가 아닙니다.** 응력자유온도는 논문의 핵심 가정이라
선생님이 결정하셔야 합니다. 그래서 1~3번은 건드리지 않고, 4번을 따로 뒀습니다.
1~3번이 잘 돌면 4번은 감도해석 한 점으로 쓰면 되고,
1~3번이 또 죽으면 4번이 "물성 때문인지 솔버 때문인지"를 갈라줍니다.

---

## 무엇을 고쳤나 (요약)

| 항목 | 어제 | 오늘 | 근거 |
|---|---|---|---|
| `dmax` | 0.99 | **0.90** | 깨진 요소가 350 GPa의 1 %(3.5 GPa)만 남겨 강성행렬이 병들었음 |
| `eta` (점성 정규화) | 0.02 | **0.05** | 증분당 손상 증가율 0.111 → 0.048 |
| `max_djump` | 0.10 | **0.03** | UMAT 자체 선제 컷백이 4배 빨리 작동 |
| `*Static` | 그냥 | **`stabilize=2e-4`** | 국부화 문제의 표준 처방 |
| 변위보정 판정 | 0.08 | **1.0** | **어제 수렴을 막은 진짜 범인** (아래) |
| `I_R` | 10 | **16** | UMAT이 시컨트 야코비안 → 1차 수렴인데 2차 기준으로 판정당함 |
| 컷백 허용 | 20 | **8** | 컷백은 도움이 안 된다는 게 증명됨 |
| 최소 증분 | 1e-12 | **1e-8** | 위와 같음 |

**어제 수렴을 막은 진짜 범인:** RT23의 7번째 반복에서 힘 잔차는 1.393e-3,
대체 허용치는 0.02 × 0.228 = 4.56e-3 — **힘은 이미 수렴했습니다.**
거부한 건 변위보정 판정이었고, 그 값은 5.3e-10 / 1.0e-9 = 0.53 대 0.08.
**둘 다 물리적으로 0인 숫자의 비율**입니다. 시간증분을 1e-12까지 줄여놨으니
당연한 일이고, 그래서 컷백 18번이 아무 소용이 없었습니다.

---

## 끝나면 보내주실 것

1. §0 의 damage census 출력 (어제 odb 3개) — **이게 제일 급합니다**
2. `M1FIX_*_ss.csv` 와 각 추출의 `ULTIMATE STRESS` 줄
3. `.sta` 와 `.msg` 의 경고
4. **ALLSD / ALLIE 비율**
5. 각 잡의 벽시계 시간
