# LTH_M8_0818_1231 — 인장 스텝을 3배로 늘려 **연화 가지를 기록**한다

## 왜 M7 대신 이것인가

M7 덱은 M6의 **인장 변형률을 그대로 물려받았습니다**(`retune_deck`이 원본 덱에서
읽어오기 때문이며, 재튜닝으로서는 옳은 기본값입니다). 그런데 M6 결과를 재보니:

| | 스텝이 덮는 변형률 | 피크 위치 | 피크 이후 |
|---|---|---|---|
| RT23 | 0.4679 % | **0.4679 %** | **0.0000 %** |
| T500 | 0.4828 % | 0.2979 % | 스텝의 75.2 %에서 사망 |
| T1000 | 0.4816 % | 0.2295 % | 0.2522 %, 16.6 % 하강 |

**RT23의 스텝은 자기 피크에서 정확히 끝납니다.** 수렴하고, 완주하고, 성공처럼
보이면서 파괴에너지는 0을 냅니다. 감쇠(`stabilize`)를 아무리 올려도 안 바뀝니다 —
**스텝이 짧은 것**이기 때문입니다. M7을 그대로 돌리면 같은 일이 반복됩니다.

## M7 덱과의 차이는 정확히 **3줄**, 전부 인장 스텝 안

| 항목 | M7 | M8 | 이유 |
|---|---|---|---|
| `ConstraintsDriver0` 변형률 | 0.0015 / 0.0032 / 0.0048 | **0.010858 / 0.012856 / 0.014432** | 스텝 구간 **×3** |
| 최대 시간증분 | 0.0025 | **0.000833333** | 구간이 3배이므로 3으로 나눔 — **증분당 변형률은 M6와 동일** |
| 증분 예산 `inc` | 2000 | **4000** | 경로가 길어졌고 연화에는 컷백이 따름 |

메시·PBC·`.ori`·모든 카드·냉각/재가열 스텝은 **M7과 바이트 동일**합니다.
`abaqus/lengthen_tension.py --check`(21항목)가 실제 M7 덱에 대해 이것을 고정합니다.

**×3인 근거**: 믿을 수 있는 유일한 연화 가지(T1000, 0.25 % 길이, 16.6 % 하강)에
$\sigma = X e^{-k(\varepsilon-\varepsilon_{pk})}$ 를 맞추면 $k$ = 84.1/strain 이고,
피크의 절반까지는 $\ln 2/k$ = **0.824 %** 가 더 필요합니다. ×3이면 세 케이스 모두
피크 이후 **0.94 / 1.15 / 1.22 %** 를 확보해 이 요구를 넘습니다.
(T500의 겉보기 $k$=4.0은 0.065 %짜리 곡선 꼭대기에 맞춘 것이라 감쇠율이 아닙니다.
설계에 쓰지 않았습니다.)

## ① 해석 실행 — 서로 독립, Abaqus Command 창 3개

    abaqus job=LTH_M8_RT23  input=LTH_M8_RT23.inp  user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
    abaqus job=LTH_M8_T500  input=LTH_M8_T500.inp  user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
    abaqus job=LTH_M8_T1000 input=LTH_M8_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"

M6보다 경로가 3배이므로 **완주 시 시간도 대략 3배**로 보십시오. 중간에 죽어도
버리지 마십시오 — 죽은 `.odb`도 **거기까지의 연화 가지는 온전**하고, 그것이
M6보다 이미 나은 자료입니다.

## ② 완료 후 — 잡 하나 끝날 때마다 그 잡부터 바로 (후처리는 수 초, cpus/memory 불필요)

    abaqus python extract_ss_curve.py LTH_M8_RT23.odb
    abaqus python damage_map.py LTH_M8_RT23.odb
    abaqus python driver_audit.py LTH_M8_RT23.odb        ← ★ ALLSD/ALLIE 5 % 관문. 이거 없이는 피크 인용 불가
    abaqus python reheat_frames.py LTH_M8_T500.odb       ← T500/T1000만 (RT23은 재가열 스텝 없음)

(T500·T1000도 같은 네 줄, 잡 이름만 바꿔서)

    python m6_verdict.py LTH_M8_RT23_ss.csv LTH_M8_T500_ss.csv LTH_M8_T1000_ss.csv
    python damage_ceiling.py LTH_M8_RT23_damage_map.csv LTH_M8_T500_damage_map.csv LTH_M8_T1000_damage_map.csv

비수렴으로 죽은 잡이 있으면:

    python msg_residual_census.py LTH_M8_T500.msg LTH_M8_T500.inp

## ★ 이번에 새로 보는 것 — `m6_verdict.py`의 **4b절**

`m6_verdict.py`가 이번 판부터 **「이 곡선이 파괴에너지를 공급할 자격이 있나」**
를 직접 판정해 출력하고 CSV에 씁니다:

    T [C]      softened     pre-peak      Gf_inel   verdict
    23             0.0 %         100 %        1.559   REFUSED: fell only 0.0 %; 100 % pre-peak

**M8이 존재하는 이유가 이 한 줄**입니다. `SUPPLIES Gf` 가 뜨면 균열대 연화가
「가정」에서 「측정」으로 올라가고, 잔여강도 절대값을 처음으로 인용할 수 있습니다.

## 채팅에 올릴 파일

- **`m6_verdict_summary.csv`** ← 가장 중요 (4b절 판정 포함)
- `damage_ceiling_summary.csv`
- `LTH_M8_*_ss.csv` (3) · `LTH_M8_*_damage_map.csv` (3)
- `LTH_M8_T500_reheat_frames.csv` · `LTH_M8_T1000_reheat_frames.csv`
- `LTH_M8_*_drivers.csv` (3 — ALLSD/ALLIE 판정 포함)
