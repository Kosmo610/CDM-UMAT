# LTH_CJFIX — CJHEAT 원인 확정, 덱 3개 재생성

압축을 `E:\LTH\` 에 풀면 `E:\LTH\LTH_CJFIX_0810_1021\` 이 됩니다.

```
E:
cd \LTH\LTH_CJFIX_0810_1021
```

**열전도 4잡(`LTH2_COND_*`)은 이 묶음과 무관합니다.** 그쪽은 계속 돌리시고,
`kbar_summary.csv` 는 따로 보내주세요.

---

## 원인 — 보내주신 에러 문구 한 줄로 확정됐습니다

```
***ERROR: Anisotropic material properties without a local orientation system
```

덱이 `*Conductivity, type=ORTHO` (방향마다 다른 열전도)를 쓰는데, **그 재료를
쓰는 단면이 좌표계를 지정하지 않았습니다.** Abaqus는 이걸 경고가 아니라
**치명적 입력 오류**로 처리합니다. 방향별 값을 줘 놓고 "어느 쪽이 1번
방향인지"를 안 알려줬으니 당연한 거부입니다.

그리고 **그 문구를 쫓다가 두 번째 결함을 찾았습니다.** 지난번 `LTH_CJ1`·
`LTH_CJ5` 의 카드에서:

```
-0.5, -0.5, 2., 0.5224, 0.5224, 0.5405, 0., 41.*Expansion, type=ORTHO, zero=1050.
```

`41.` 뒤에 **줄바꿈이 빠져** `*Expansion` 이 숫자 줄에 붙었습니다. 제가
카드의 한 값(RTH 0.30 → 0.10)을 손으로 고치면서 낸 실수입니다. **CJ1·CJ5는
CJHEAT가 고쳐졌어도 여기서 또 죽었을 것입니다.**

| | 무엇 | 누구 잘못 | 영향 |
|---|---|---|---|
| 결함 A | `*Orientation` 없음 | **덱 생성기** | 모든 거시 덱 (열·역학 전부) |
| 결함 B | `*Expansion` 줄 붙음 | **제가 손으로 고친 것** | 지난번 CJ1·CJ5 |

## 무엇을 고쳤나

**A** — 생성기가 이제 좌표계를 명시합니다. 항등 좌표계이지만 **적어놓는 것이
중요합니다**: 카드의 1축 = 날실 = 전역 x, 3축 = 두께 = 전역 z(급랭 방향)라는
대응을 덱에서 선언하는 유일한 자리이고, $\alpha_1/\alpha_3$·$\bar k_1/\bar k_3$
가 전부 여기에 걸려 있습니다.

```
*Orientation, Name=MACRO_AXES
1., 0., 0., 0., 1., 0.
3, 0.
*Solid Section, ElSet=ALL, Material=..., Orientation=MACRO_AXES
```

**B** — 카드 값 변경을 손편집이 아니라 `--card-slot 42=0.10` 으로 합니다.
데이터 줄을 통째로 다시 쓰므로 줄바꿈이 깨질 수 없습니다.

**그리고 두 결함을 잡는 정적 검사를 생성기에 박았습니다** — 솔버 없이
덱만 읽어서, ① ORTHO 물성을 쓰는 단면에 좌표계가 없으면, ② 숫자 줄 뒤에
키워드가 숨어 있으면 즉시 실패합니다. 두 검사 모두 **실제 결함을 넣었을 때
실제로 걸리는지**까지 확인했습니다.

> 재생성한 덱이 지난번과 **같은 덱임을 확인했습니다**: 스텝 수 43 / 11 / 4로
> 동일하고, 카드 56슬롯도 동일합니다(RTH = 0.10 포함). 바뀐 것은 위 두 가지뿐입니다.

---

# ① 실행

## 1파 — `LTH_CJHEAT` 먼저. 창 1개

```
abaqus job=LTH_CJHEAT input=LTH_CJHEAT.inp double interactive cpus=2 memory="8gb"
```

**이번엔 통과해야 합니다.** 또 죽으면 문구를 파일로 뽑아 주세요:
```
findstr /I "ERROR" LTH_CJHEAT.dat > CJHEAT_error2.txt
```

## 2파 — 위가 끝난 뒤. **창 2개 병렬**

역학 잡이 열 ODB(`LTH_CJHEAT.odb`)를 읽으므로 **이것만 순서가 있습니다.**

**창 A**
```
abaqus job=LTH_CJ1 input=LTH_CJ1.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="40gb"
```
**창 B**
```
abaqus job=LTH_CJ5 input=LTH_CJ5.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="40gb"
```

메시가 720요소라 코어를 더 줘도 안 빨라집니다.
**CJ5(11스텝)가 먼저 끝나고 CJ1(43스텝)이 더 걸립니다.**

---

# ② 완료 후 — **CSV 3개를 보내주세요**

## A. E(N) 추출 — 잡 하나 끝날 때마다 바로 (`abaqus python`)

```
abaqus python extract_probe.py LTH_CJ1.odb
abaqus python extract_probe.py LTH_CJ5.odb
```
→ `LTH_CJ1_EN.csv`, `LTH_CJ5_EN.csv` ← **둘 다 올려주세요**

## B. 점프 오차 판정 (**일반 `python`** — CSV만 읽습니다)

```
python compare_cyclejump.py LTH_CJ1_EN.csv LTH_CJ5_EN.csv
```

- **< 1 %** 무시 가능 → 고정 점프 확정
- **1–3 %** 허용 → 모든 E(N) 결과 옆에 이 숫자 병기
- **> 3 %** 너무 거침 → 점프 절반으로 줄여 재실행

## C. 손상 지도 — 첫 실물 시험 (해석 시간 0초 추가)

```
abaqus python damage_map.py LTH_CJ1.odb --axis z --top 30
```
→ `LTH_CJ1_damage_map.csv` ← **이것도 올려주세요**

동시에 ODB에 `DAMG`·`DMODE`·`DADD` 필드가 붙습니다. Viewer에서
**Result → Field Output → `DAMG`**. `DADD`로 바꾸면 제조 냉각을 뺀
**열충격이 새로 낸 손상**만 나옵니다.

> 실제 ODB에서 한 번도 안 돌려본 코드입니다. **에러가 나면 그 문구를 그대로**
> 알려주세요 — 해석 결과에는 아무 영향이 없고, 그게 이번에 얻는 정보입니다.

---

# ③ 겸사 확인 (한 줄만)

`LTH_CJ1_EN.csv` 의 **`twmax_prev_block` 열이 900** 이면, 사이클 블록이 정말
최고온도에 앉아 있었다는 뜻입니다 — UMAT에 새로 넣은 **사이클 심각도 창
(SDV 29)** 이 실제 해석에서 작동했다는 첫 실물 증거입니다.
**900이 아니면 그 값을 그대로** 알려주세요.

---

# 파일 목록

| 파일 | 무엇 | UMAT |
|---|---|---|
| `LTH_CJHEAT.inp` | 열전달 — **CJ1·CJ5가 공유**. 좌표계 추가됨 | 불필요 |
| `LTH_CJ1.inp` | 명시적 20사이클 (43스텝). 두 결함 모두 수정 | **필요** |
| `LTH_CJ5.inp` | 5배 점프 (11스텝). 두 결함 모두 수정 | **필요** |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT | — |
| `extract_probe.py` | E(N) 추출 — `abaqus python` | — |
| `compare_cyclejump.py` | 점프 오차 판정 — 일반 `python` | — |
| `damage_map.py` | 손상 지도 — `abaqus python` | — |

> 지난번 `LTH_RUN2_0810_0930` 폴더는 **지우지 마세요.** 열전도 4잡이 거기
> 있고, `LTH_CJHEAT.dat` 의 옛 에러도 논문 부록(정적 검증의 한계 사례)에
> 쓸 수 있습니다.
