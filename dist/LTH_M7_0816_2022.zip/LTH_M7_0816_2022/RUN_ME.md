# LTH_M7_0816_2022 — M7: 감쇠 한 단계 + 슬롯 35 적법화

**M6 덱과의 차이는 정확히 두 가지**이고, 저장소 검사가 바이트 대조로 고정합니다:

| 항목 | M6 | M7 | 성격 |
|---|---|---|---|
| 얀 슬롯 35 (Gtc) | 0.107 | **0** | 적법성 수정 — 인장 Gf를 압축에 쓴 것 정리. 이 하중경로에서 모드 24 손상부피 0이므로 결과 무해 |
| `*Static stabilize` | 2e-4 | **1e-3** | **유일한 거동 변경** (한 단계만). `allsdtol=0.05`가 감쇠를 5 %로 묶음 |

메시·PBC·`.ori`·나머지 카드 전부 M6와 바이트 동일. `ftol`은 그대로 0.02
(소진 판정 — T500 잔차가 그 기준의 73배였음).

## ① 해석 실행 — 서로 독립, Abaqus Command 창 3개

    abaqus job=LTH_M7_RT23  input=LTH_M7_RT23.inp  user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
    abaqus job=LTH_M7_T500  input=LTH_M7_T500.inp  user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
    abaqus job=LTH_M7_T1000 input=LTH_M7_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"

## ② 완료 후 — 잡 하나 끝날 때마다 그 잡부터 바로 (후처리는 수 초, cpus/memory 불필요)

    abaqus python extract_ss_curve.py LTH_M7_RT23.odb
    abaqus python damage_map.py LTH_M7_RT23.odb
    abaqus python driver_audit.py LTH_M7_RT23.odb        ← ★ ALLSD/ALLIE 5 % 관문. 이거 없이는 피크 인용 불가
    abaqus python reheat_frames.py LTH_M7_T500.odb       ← T500/T1000만 (RT23은 재가열 스텝 없음)

(T500·T1000도 같은 네 줄, 잡 이름만 바꿔서)

    python m6_verdict.py LTH_M7_RT23_ss.csv LTH_M7_T500_ss.csv LTH_M7_T1000_ss.csv
    python damage_ceiling.py LTH_M7_RT23_damage_map.csv LTH_M7_T500_damage_map.csv LTH_M7_T1000_damage_map.csv

비수렴으로 죽은 잡이 있으면:

    python msg_residual_census.py LTH_M7_T500.msg LTH_M7_T500.inp

## 채팅에 올릴 파일

- `m6_verdict_summary.csv` · `damage_ceiling_summary.csv`
- `LTH_M7_*_ss.csv` (3) · `LTH_M7_*_damage_map.csv` (3)
- `LTH_M7_T500_reheat_frames.csv` · `LTH_M7_T1000_reheat_frames.csv`
- `LTH_M7_*_drivers.csv` (3 — ALLSD/ALLIE 판정 포함)
