# M1 (거친 메시, 자기완결) — Zhang 2022 재현 3케이스

**패키지 생성: 2026-07-28 KST** · **대상: 32코어 / 256 GB**
**메시: TexGen 0.135 mm, 26,452 C3D4 / 5,686 노드**

---

## ✅ 외부 파일 필요 없습니다

`.ori` 방향 데이터(26,453행)를 **덱 안에 내장**했습니다. 압축만 풀면 바로 돕니다.
따로 챙길 파일이 없습니다.

---

## 실행 — 세 잡은 서로 완전히 독립입니다

> ### **Abaqus Command 창을 3개 열고, 각각에 하나씩 입력하세요.**

**1번 창**
```
abaqus job=Job-c26k-RT23 input=abaqus/ZHANG2022_c26k_RT23.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

**2번 창**
```
abaqus job=Job-c26k-T500 input=abaqus/ZHANG2022_c26k_T500.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

**3번 창**
```
abaqus job=Job-c26k-T1000 input=abaqus/ZHANG2022_c26k_T1000.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

약 17k 자유도로 작은 모델이라 `cpus=8`, `memory="30gb"` 면 충분합니다
(3 x 8 = 24코어 / 90 GB). `double` 은 **필수**.
토큰이 부족하면 `cpus=4` 로 낮추되 **잡 개수는 줄이지 마세요.**

---

## 끝난 뒤

```
abaqus python postprocess/extract_ss_curve.py Job-c26k-RT23.odb
abaqus python postprocess/extract_ss_curve.py Job-c26k-T500.odb
abaqus python postprocess/extract_ss_curve.py Job-c26k-T1000.odb

python postprocess/plot_compare.py Job-c26k-RT23_ss.csv Job-c26k-T500_ss.csv Job-c26k-T1000_ss.csv
```

---

## 제가 검증해 둔 것 (솔버 없이, 다시 안 하셔도 됨)

| 항목 | 결과 |
|---|---|
| 요소 / 노드 | 26,452 C3D4 / 5,686 |
| RVE 치수 | 3.5 x 3.5 x 0.44 mm, V = **5.39 mm3**, 충전율 100 % |
| ElSet | Matrix(15,369) + Yarn0(2,745)/Yarn1(2,811)/Yarn2(2,763)/Yarn3(2,764) |
| PBC | `*Equation` 57식, 드라이버 5681-5686 |
| **섬유체적비** | 얀 0.4982 x 0.79194 = **39.46 %** (카드 39.6 %, Zhang "약 40 %") |
| `.ori` 정합성 | 26,452 라벨행 + 기본행 1, 라벨 1..26452 연속, **누락 0개** |
| 얀 방향 | Yarn0/1 = (0.993, 0, +-0.008) **warp || x** · Yarn2/3 = (0, 0.993, +-0.004) **weft || y** |
| 매트릭스 방향 | 100 % 단위행렬 (등방성이라 정상) |
| 드라이버 매핑 | `0=e_x 1=e_y 2=e_z 3=e_xy 4=e_xz 5=e_yz` |

**두 가지가 특히 중요했습니다.**

1. **섬유체적비 39.46 %** — 검증된 카드(39.6 %)와 상대차 0.35 %.
   이 거친 메시가 미세 메시와 **같은 복합재**를 나타낸다는 뜻이고,
   나중에 "결과 차이 = 순수 이산화 차이"라고 말할 수 있는 전제입니다.

2. **`.ori` 정합성** — 라벨이 요소와 1:1로 연속 대응하고 누락이 0개입니다.
   여기가 어긋나면 **에러 없이 섬유 방향이 틀린 채로 수렴**하므로 가장 위험합니다.
   얀 평균 방향이 warp = x, weft = y 로 직교하고 크기 0.993(<1)이라
   굴곡(crimp)까지 정상입니다.

**전단 순서 확정:** `--shear-order xy-xz-yz` (기본값). PBC 식이
`FaceA - FaceB - Lx*U_d0 = 0` 이므로 **U(드라이버) = 거시 변형률** 그대로.

---

## 목표값

| 온도 | Zhang Table 3 |
|---|---|
| 23 C | **128.45 MPa** |
| 500 C | **179.42 MPa** |
| 1000 C | **199.15 MPa** |

**첫 실행에서 안 맞는 게 정상입니다** — 논문 미공개 파라미터 보정이 필요하고,
거친 메시는 그 반복을 빠르게 하려는 것입니다. 절차는 `CALIBRATION_GUIDE.md`.

## 보내주실 것

`.odb` 말고:
1. **`*_ss.csv` 3개**
2. **`.sta` 3개** (수렴 이력)
3. `.msg` 경고/에러 있으면 그 부분
4. **각 잡 소요 시간** - 다음 단계 RVE 가상시험(모드 8 x 온도 3)의 분할 계획에 씁니다
