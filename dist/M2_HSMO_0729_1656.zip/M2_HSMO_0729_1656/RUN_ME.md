# M2 — 0729_1656  (I1 스무딩)

**폴더 안 나눴습니다. 압축 풀고 그 자리에서 바로 명령어 치시면 됩니다.**

---

## 0. 먼저 — 어제 M1FIX_RT23 결과부터 뽑으세요 (해석 X, 10초)

죽었지만 **인장 스텝을 65 증분까지 갔습니다.** 실제 곡선이 들어있습니다.

```
abaqus python extract_ss_curve.py M1FIX_c26k_RT23.odb
```
```
abaqus python damage_census.py M1FIX_c26k_RT23.odb
```

`damage_census` 맨 위의 **`field output in this frame: ...`** 한 줄 꼭 보내주세요.
SDV가 목록에 있는지 없는지가 다음 진단을 가릅니다.

---

## ① 실행 — **UMAT이 V3_0으로 바뀝니다. V1_0 아닙니다.**

돌고 있는 3개(T500 / T1000 / z600)는 **그냥 두세요.** 끝나면 데이터가 됩니다.
아래는 그것들이 끝난 뒤에 돌리시면 됩니다.

**창 1**
```
abaqus job=M2_c26k_RT23 input=M2_c26k_RT23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

**창 2**
```
abaqus job=M2_c26k_T500 input=M2_c26k_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

**창 3**
```
abaqus job=M2_c26k_T1000 input=M2_c26k_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

> **`user=` 파일명이 다릅니다.** V1_0을 쓰면 즉시 죽습니다 —
> 매트릭스 카드가 22개에서 **25개**로 늘어서 V1_0이 거부합니다.
> (일부러 그렇게 만들어놨습니다. 조용히 틀리는 것보다 낫습니다.)

---

## ② 해석 완료 후 명령

### (a) 응력–변형률 CSV — **`abaqus python`**

잡 하나 끝날 때마다 바로. 셋 다 기다릴 필요 없습니다.

```
abaqus python extract_ss_curve.py M2_c26k_RT23.odb
```
```
abaqus python extract_ss_curve.py M2_c26k_T500.odb
```
```
abaqus python extract_ss_curve.py M2_c26k_T1000.odb
```

→ `M2_c26k_RT23_ss.csv` 등. 화면에 `ULTIMATE STRESS`, `initial modulus`,
`applied strain range`가 찍힙니다. 곡선이 아직 올라가는 중이면
**"이건 극한강도가 아니다"**라고 경고가 뜹니다 — 그 경고 여부도 알려주세요.

### (b) 손상 분포 — **`abaqus python`**

```
abaqus python damage_census.py M2_c26k_RT23.odb
```

### (c) 그림 — **`python3`** (일반 파이썬, matplotlib 필요)

```
python3 plot_compare.py M2_c26k_RT23_ss.csv M2_c26k_T500_ss.csv M2_c26k_T1000_ss.csv
```

### (d) ALLSD / ALLIE — **필수**

CAE → XY Data → ODB history output → `ALLSD`, `ALLIE`.

> **ALLSD / ALLIE < 0.05 (5 %)** 인지 확인.

넘으면 피크 응력이 인공 감쇠로 부풀려진 것이라 논문에 못 씁니다.

---

## 무엇을 고쳤나

어제 RT23은 인장 스텝 **0.133**까지 갔습니다 (그 전엔 0.0892 — **49 % 더**).
하지만 또 멈췄고, `.msg`의 마지막 두 반복이 원인을 정확히 말해줍니다:

```
반복 12   잔차  5.104E-03   변위보정 +1.709E-09
반복 13   잔차 -3.833E-02   변위보정 -1.709E-09
```

**변위보정이 크기는 똑같고 부호만 뒤집혔습니다.** 완벽한 2-사이클 진동입니다.
변위가 1e-9(=0)인데 잔차가 7.5배 튀었다는 건, **변형률이 안 변하는데 응력이 튀었다**는
뜻이고, 그건 물질법칙에 **불연속 스위치**가 있다는 뜻입니다.

그 스위치는 하나뿐입니다. Ge Eq.7:

```
d_act = d_인장   (I1 >= 0)
d_act = d_압축   (I1 <  0)
```

인장으로 손상된 점은 `d_인장 = 0.9`, `d_압축 = 0`입니다.
**I1이 0을 스치는 순간 강성이 E(1−0.9) → E, 즉 10배로 튑니다.**
컴파일된 Fortran으로 직접 측정했습니다:

```
HSMO=0     I1=0 을 지날 때 응력 계단이 평소의  78.0 배  -> 점프
HSMO=0.1   I1=0 을 지날 때 응력 계단이 평소의   2.3 배  -> 연속
```

수정: 계단을 tanh 블렌딩으로 바꿨습니다 (반폭 = HSMO × Xt).

```
w     = 0.5*(1 + tanh(I1/(HSMO*Xt)))
d_act = w*d_인장 + (1-w)*d_압축
```

- **HSMO = 0 이면 논문 원식과 비트 단위로 동일**합니다 → 검증이 안 깨집니다
- 손상 이력(d_인장, d_압축)은 손대지 않았습니다 → 손상이 생기거나 회복되지 않습니다
- **V1_0은 동결 유지.** 이 기능은 논문 라인 UMAT인 **V3_0**에만 들어갔습니다

### 왜 하필 이 스위치가 문제인가 — 메시 때문입니다

`.dat`에 이렇게 적혀 있습니다:

```
***WARNING: 1185 elements are distorted.
```

- **1185개 = 전체의 4.5 %**, 그리고 **전부 매트릭스** (얀은 0개)
- 최악 품질 **0.00089** (아바쿠스 권장 > 0.02, 549개가 미달)
- 최소 이면각 **0.313°** (권장 > 10°, **428개가 1° 미만**)

TexGen이 얀 표면은 잘 깎지만, 그 사이 빈틈을 매트릭스로 채울 때
**바늘처럼 납작한 사면체(sliver)**가 생깁니다. 이런 요소는 응력 상태가 극단적으로
왜곡돼서 **I1이 0 근처에 걸터앉기 쉽습니다.** 그래서 스위치가 매 반복마다 깜빡입니다.

실제로 어제도 오늘도 **똑같은 노드(1080 / 1081, 자유도 3)**에서 죽었고,
노드 1081 주변 요소의 **21 %가 왜곡 요소**입니다 (평균은 4.1 %). 5배입니다.

---

## 이번에도 안 되면

그때는 **메시를 다시 뽑아야 합니다.** 스무딩은 스위치를 없애주지만
sliver 요소 자체의 나쁜 조건수는 못 고칩니다. TexGen에서 다시 뽑을 때
매트릭스 쪽 요소 품질을 올리는 옵션을 봐야 합니다.
**`.ori`도 반드시 같이 다시 뽑아야 합니다** — 옛 `.ori`를 새 메시에 쓰면
에러 없이 섬유 방향이 틀린 채로 수렴합니다.

---

## 보내주실 것

1. `M1FIX_c26k_RT23_ss.csv` 와 `damage_census`의 `field output in this frame:` 줄
2. 돌고 있는 3개(T500 / T1000 / z600)의 `.sta` 마지막 줄
3. `M2_*` 결과: `*_ss.csv`, `ULTIMATE STRESS` 줄, `.sta`, ALLSD/ALLIE
