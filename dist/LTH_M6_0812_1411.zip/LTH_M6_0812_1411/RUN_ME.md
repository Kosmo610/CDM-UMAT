# LTH_M6 — 출처 있는 카드로 미시 검증(L2) 최종 관문 (잡 3개, 전부 병렬, ~4시간)

압축을 `E:\LTH\` 에 풀면 `E:\LTH\LTH_M6_0812_1411\` 이 됩니다.

```
E:
cd \LTH\LTH_M6_0812_1411
```

**폴더 이름을 바꾸셨으면 `cd` 줄만 고치세요.** 나머지는 전부 상대 경로입니다.

---

## 왜 돌리는가 — M1~M5와 무엇이 다른가

M5까지는 **Zhang 2022의 카드를 그대로** 썼고, T1000 인장이 목표(199.15 MPa)의
1.64배인 326.70 MPa에서 아직 오르는 중이었습니다. 그 1.64배는 **그 논문 물성
세트의 성질**이었습니다. M6는 카드를 **1차 구성재 문헌에서 다시 세웠습니다**:

| 카드 | M5 | **M6** | 근거 |
|---|---|---|---|
| 기지 $E$ | 350 000 | **213 110 MPa** | 공극률 32.4 % 반영 (열전도 해석과 같은 카드) |
| 얀 $X_t$ | 2835 | **474.7 / 581.4 / 694.4 MPa** | 실측 단섬유 Weibull에서 in-situ 재유도 |
| 얀 $G_{tt}, G_{tc}$ | 0 | **0.107 N/mm** | 0이면 균열대가 꺼져 그 모드가 메시 의존 |

그래서 **Zhang Table 3(128.45 / 179.42 / 199.15 MPa)는 재현 대상이 아니라
독립 검증 목표**입니다.

**M5 진단의 검증이기도 합니다**: M5 비수렴 잔차의 41–57 %가 횡방향 얀(균열대
꺼진 상)에 몰려 있었습니다. $G_{tt}=G_{tc}=0.107$로 켠 것이 정확히 그 모드라,
**M6가 더 멀리 가면 그 진단이 맞았다는 실물 증거**가 됩니다.

## 한 잡에서 두 가지가 분리되어 나옵니다

| 보는 곳 | 검증 대상 | 판정 기준 |
|---|---|---|
| **초기 접선** | 공극률 보정 | refs/[10] 실측 128.7(RT) / 172.7(1000 °C) GPa |
| **파단변형률에서의 응력** | 얀 $X_t$ | Zhang Table 3 |

초기 접선은 손상 **전에** 정해지므로 $X_t$가 손댈 수 없습니다 — 두 보정이
곡선의 다른 부분에 나타나 잡을 더 만들 필요가 없습니다.

> **★ UMAT이 0810 묶음보다 새롭다 (2026-08-12).** 그 사이 a1이 Ge Eqs.(31)-(33)
> 일관 접선을 넣어 소스가 1411 → 2125줄이 되었다. **M6 결과는 바뀌지 않는다** —
> 새 기능은 카드에 `ITAN` 블록이 있을 때만 켜지고, 이 덱들의 카드(기지 25슬롯 ·
> 얀 38슬롯)에는 그 블록이 없다. `cross_check_fortran.py`가 바로 그 두 카드
> 폭에 대해 **79개 상태 전부에서 STRESS·STATEV·DDSDDE가 비트 단위로 동일**함을
> 확인한다(worst rel. dev. 0.00e+00). 덱 3개는 손대지 않았다.
>
> **0803 묶음과의 관계.** 덱 3개는 0803 정본과 **동일**합니다(오늘 좌표계·
> 키워드접합 정적 감사 2종을 통과시켜 재확인). 바뀐 것은 UMAT(현행 V3_0,
> 엄격한 상위집합)과 판독기들 — 특히 `damage_map.py`(RVE 첫 투입)와
> `extract_pls.py`가 새로 들어갔습니다.

---

# ① 실행 — **3잡 전부 병렬.** 창 3개

**UMAT 필수** (HSMO=0.1 카드 = 25슬롯, V3_0 전용).

창 1
```
abaqus job=LTH_M6_RT23 input=LTH_M6_RT23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```
창 2
```
abaqus job=LTH_M6_T500 input=LTH_M6_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```
창 3
```
abaqus job=LTH_M6_T1000 input=LTH_M6_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

- 합계 **30코어 / 210 GB** (OS 여유 2코어). 라이선스 토큰 잡당
  `int(5·10^0.422)` = **13**, 3잡 **39**. **모자라면 `cpus=8`** (잡당 12토큰,
  합계 36). 잡 수는 줄이지 마세요.
- 예상: 잡당 1~4시간 (M5 실측 0.64~3.54 h). **완주 못 해도 정상일 수 있습니다**
  — 마지막 수렴 증분까지의 곡선이 판정 대상입니다.
- **잡이 죽으면** odb를 지우지 말고 그대로 두세요. ②는 죽은 잡에도 돌아갑니다.

# ② 완료 후 — 잡 하나 끝날 때마다 바로

## A. 응력-변형률 곡선 (ODB → `abaqus python`)

```
abaqus python extract_ss_curve.py LTH_M6_RT23.odb
abaqus python extract_ss_curve.py LTH_M6_T500.odb
abaqus python extract_ss_curve.py LTH_M6_T1000.odb
```
→ `LTH_M6_RT23_ss.csv` 등 3개

## B. 판정 (셋 다 나온 뒤, **일반 `python`**)

```
python m6_report.py LTH_M6_RT23_ss.csv LTH_M6_T500_ss.csv LTH_M6_T1000_ss.csv
python m6_verdict.py LTH_M6_RT23_ss.csv LTH_M6_T500_ss.csv LTH_M6_T1000_ss.csv
python extract_pls.py LTH_M6_RT23_ss.csv LTH_M6_T500_ss.csv LTH_M6_T1000_ss.csv
```

## C. 손상 지도 — RVE 첫 투입 (ODB → `abaqus python`)

```
abaqus python damage_map.py LTH_M6_RT23.odb --axis x --top 30
```
→ `LTH_M6_RT23_damage_map.csv` + ODB에 `DAMG`·`DMODE`·`DADD` 필드.
Viewer에서 **Result → Field Output → DAMG** 로 기지·얀 손상을 한 장으로,
`DADD` 로 냉각분을 뺀 인장 손상만 봅니다. `--axis x` 인 이유: 하중이 x이므로
국소화 밴드는 x를 따라 나타납니다.

## D. 잡이 죽었을 때만 — .msg 진단 (ODB 불필요, **일반 `python`**)

```
python msg_residual_census.py LTH_M6_RT23.msg LTH_M6_RT23.inp
```

# ③ 올려주실 파일

| 파일 | 언제 |
|---|---|
| **`LTH_M6_RT23_ss.csv` · `LTH_M6_T500_ss.csv` · `LTH_M6_T1000_ss.csv`** | 항상 (죽은 잡 포함) |
| **`LTH_M6_RT23_damage_map.csv`** | C를 돌린 뒤 |
| `LTH_M6_*.msg` 의 census 출력 캡처 대신 → 콘솔 텍스트를 파일로 | 잡이 죽었을 때만 |

# 파일 목록

| 파일 | 무엇 | 실행기 |
|---|---|---|
| `LTH_M6_RT23/T500/T1000.inp` | 냉각+인장 2스텝, 자기완결(.ori 인라인) | — |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | 현행 UMAT (25슬롯 HSMO 카드 필수) | — |
| `extract_ss_curve.py` | 곡선 → CSV | `abaqus python` |
| `m6_report.py` / `m6_verdict.py` | 피크·접선 판정 | 일반 `python` |
| `extract_pls.py` | 비례한도 4정의 | 일반 `python` |
| `damage_map.py` | 손상 지도 (DAMG/DMODE/DADD + CSV) | `abaqus python` |
| `damage_census.py` / `driver_audit.py` | 보조 진단 | `abaqus python` |
| `msg_residual_census.py` | 죽은 잡 진단 (.msg만) | 일반 `python` |
