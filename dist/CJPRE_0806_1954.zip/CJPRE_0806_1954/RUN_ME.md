# CJPRE — cycle-jump 오차 선행검증 (잡 3개, 총 수 분~수십 분)

**목적.** 본 매트릭스(3 심각도 × 3 TRS)는 cycle jump(한 증분 = 5사이클)로
돕니다. 재료점 수준 오차는 0.03 %로 검증돼 있지만(제3장 T6), **구조 수준**
오차 — 손상 재분배를 점프가 뭉개는 양 — 은 한 번 실측해야 합니다.
같은 20사이클을 **명시적(jump=1)** 과 **점프(jump=5)** 로 돌려 E(N=20)을
비교합니다. 이것이 refs/[58]의 적응 제어를 "안 넣는" 우리 근거 자료가 됩니다.

이 덱은 V3_0의 **T_max 창(SDV 29)** 이 든 첫 실전 덱이기도 합니다.

> ⚠️ 카드의 RTH(슬롯 42)를 0.30 → **0.10**으로 낮춰 두었습니다.
> 선행검증에서 d_cyc가 확실히 쌓이게 하기 위한 것으로, **보정값이 아닙니다.**

---

## ① 해석 실행 명령

**1단계 — 열 잡 1개 (먼저, 혼자):**

```
abaqus job=CJ_HEAT_SZ input=CJ_HEAT_SZ.inp double interactive cpus=2 memory="8gb"
```

수 분이면 끝납니다. **이 잡이 끝난 뒤에** 2단계로 갑니다(역학이 열 ODB를 읽음).

**2단계 — 역학 잡 2개 (서로 독립 → 병렬).**
**Abaqus Command 창을 2개 열고 각각 하나씩 입력하세요** (열 잡과 같은 폴더에서):

창 1:
```
abaqus job=CJ1_MECH_SZ_TRSC input=CJ1_MECH_SZ_TRSC.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="20gb"
```

창 2:
```
abaqus job=CJ5_MECH_SZ_TRSC input=CJ5_MECH_SZ_TRSC.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="20gb"
```

- 메시가 720요소로 작아 코어를 더 줘도 빨라지지 않습니다. 6+6+OS 여유로 충분.
- CJ5(11스텝)가 먼저 끝나고 CJ1(43스텝)이 더 걸립니다. **하나 끝날 때마다
  바로 ②의 해당 후처리를 돌려도 됩니다.**

## ② 해석 완료 후 명령

각 역학 잡이 끝나면 (ODB를 읽으므로 **반드시 `abaqus python`**):

```
abaqus python extract_probe.py CJ1_MECH_SZ_TRSC.odb
abaqus python extract_probe.py CJ5_MECH_SZ_TRSC.odb
```

→ `CJ1_MECH_SZ_TRSC_EN.csv`, `CJ5_MECH_SZ_TRSC_EN.csv`
(N별 강성 E, E/E0, d_cyc 평균/최대, 블록의 TWMAX)

둘 다 나오면 비교·판정 (일반 `python`):

```
python compare_cyclejump.py CJ1_MECH_SZ_TRSC_EN.csv CJ5_MECH_SZ_TRSC_EN.csv
```

판정이 그대로 출력됩니다:
- **< 1 %** : 무시 가능 — 고정 점프 확정, [57][58] 인용으로 종결
- **1–3 %** : 허용 — 모든 E(N) 결과 옆에 이 숫자를 병기
- **> 3 %** : 점프를 절반으로 줄이거나 적응 제어 구현 후 재실행

## 겸사 확인 (공짜)

`_EN.csv`의 `twmax_prev_block` 열이 **900**(= T_hi)이면, 사이클 블록이
정말 최고온도에 앉아 있었다는 감사가 통과된 것입니다. 900이 아니면
그 값 그대로 채팅에 알려주세요.

## 파일 목록

| 파일 | 역할 |
|---|---|
| `CJ_HEAT_SZ.inp` | 열전달 (두 역학 잡이 **공유**) |
| `CJ1_MECH_SZ_TRSC.inp` | 명시적 20사이클 (43스텝) |
| `CJ5_MECH_SZ_TRSC.inp` | 5배 점프 (11스텝) |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT (T_max 창 포함) |
| `extract_probe.py` | E(N) 추출 — `abaqus python` |
| `compare_cyclejump.py` | 비교·판정 — 일반 `python` |
