# 오늘 한 번에 돌릴 것 전부 (0803 19:09 KST)

**M6 3잡 + RVE_COND 4잡을 한 폴더에 합쳤습니다.** 압축 풀고 이 문서만 따라가면 됩니다.

---

## ★ 먼저 정정 — 제가 앞서 "같이 걸어두세요"라고 한 건 자원 초과였습니다

M6를 `cpus=10` 3개(30코어/210 GB)로 돌리면서 RVE_COND를 `cpus=8`(55 GB)로 얹으면
**38코어 / 265 GB**가 필요합니다. 32코어 / 256 GB에서는 안 됩니다.

| 계획 | 코어 | 메모리 | 토큰 | |
|---|---|---|---|---|
| 앞서 말한 것 (M6 3×10 + RVE 8) | 38 | 265 GB | 51 | ❌ 초과 |
| 진짜 동시 (M6 3×9 + RVE 2) | 29 | 194 GB | 42 | △ 토큰 위험 |
| **RVE 먼저 → M6** | — | — | 최대 39 | ✅ **권장** |

**권장안이 손해가 거의 없습니다.** RVE_COND는 **선형 정상상태**라 4개 합쳐 **몇 분**이면
끝납니다. 그 몇 분 뒤 M6를 원래대로 `cpus=10` 3개로 띄우면 됩니다.
(토큰도 지금까지 쓰던 39개 그대로입니다.)

---

# 1단계 — RVE_COND 4잡 (창 1개, 몇 분)

**`user=` 가 없습니다.** UMAT을 쓰지 않는 선형 열전도 해석입니다.

```
abaqus job=RVE_COND_P00_k8  input=RVE_COND_P00_k8.inp  double interactive cpus=8 memory="55gb"
abaqus job=RVE_COND_P05_k8  input=RVE_COND_P05_k8.inp  double interactive cpus=8 memory="55gb"
abaqus job=RVE_COND_P32_k8  input=RVE_COND_P32_k8.inp  double interactive cpus=8 memory="55gb"
abaqus job=RVE_COND_P32_k60 input=RVE_COND_P32_k60.inp double interactive cpus=8 memory="55gb"
```

**끝나면 바로:**

```
abaqus python extract_kbar.py RVE_COND_P00_k8.odb RVE_COND_P05_k8.odb RVE_COND_P32_k8.odb RVE_COND_P32_k60.odb
```

→ `kbar_summary.csv` 생성. **이게 오늘 나오는 첫 결과입니다.**

---

# 2단계 — M6 3잡 (창 3개, 병렬)

RVE_COND가 끝난 뒤 **창 3개를 열고** 각각 하나씩.

**창 1**
```
abaqus job=M6_c26k_RT23 input=M6_c26k_RT23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

**창 2**
```
abaqus job=M6_c26k_T500 input=M6_c26k_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

**창 3**
```
abaqus job=M6_c26k_T1000 input=M6_c26k_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=10 memory="70gb"
```

## M6 잡 하나가 끝날 때마다 바로 (3개 다 기다릴 필요 없음)

`<잡>` 자리에 `M6_c26k_RT23` 등을 넣으세요.

```
abaqus python extract_ss_curve.py <잡>.odb
abaqus python damage_census.py <잡>.odb > <잡>_census.txt
```

**3개 다 끝난 뒤:**
```
python m6_verdict.py M6_c26k_RT23_ss.csv M6_c26k_T500_ss.csv M6_c26k_T1000_ss.csv
```
> `m6_verdict.py`는 **일반 `python`** 입니다 (ODB를 읽지 않음).

---

# 3단계 — (여유 되면) M5 ODB에서 곡선 뽑기

M5 결과가 아직 디스크에 있으면 **수 분**이면 됩니다. 죽은 잡의 ODB도 마지막
수렴 증분까지 온전합니다.

```
abaqus python extract_ss_curve.py M5_c26k_RT23.odb
abaqus python extract_ss_curve.py M5_c26k_T500.odb
abaqus python extract_ss_curve.py M5_c26k_T1000.odb
abaqus python damage_census.py M5_c26k_T1000.odb > M5_census_T1000.txt
```

> **왜 필요한가.** M5는 `*Static, stabilize=`로 돌았습니다. **인공 안정화 에너지
> `ALLSD/ALLIE`가 5 %를 넘으면 M5의 응력값은 전부 못 씁니다** — 그러면 M6를
> 비교할 기준선이 사라집니다. 그 값은 ODB에만 있습니다.

---

# 오늘 끝나면 보내주실 것

| 파일 | 무엇을 판정하나 |
|---|---|
| `kbar_summary.csv` | **$\bar k$ 확정 → 6~7단계 개방** |
| `M6_c26k_*_ss.csv` (3개) | **공극률 보정 + 얀 $X_t$ 보정 판정 → 5단계** |
| `M6_c26k_*_census.txt` (3개) | ATEFF 취성 고정 비율 (**강도 인용 전 필수**) |
| `M5_c26k_*_ss.csv` (3개, 있으면) | M5 기준선 + `ALLSD/ALLIE` |

---

# 미리 알아두실 것 (실패가 아닌 것들)

1. **M6 23 °C는 그래프가 꼭대기 없이 끝납니다.** 얀 파단변형률 0.186 %가
   덱이 당기는 0.150 %보다 뒤에 있습니다. **설계된 결과입니다.**
2. **RVE_COND에서 $\bar k_1 \ne \bar k_2$ 면 그때는 진짜 문제입니다.** 균형 평직이라
   같아야 하고, 서로 다른 두 해석에서 나온 값이라 어긋나면 면 절점집합이나
   메시를 의심해야 합니다. `extract_kbar.py`가 자동으로 판정합니다.
3. **M6가 또 70 % 근처에서 멈춰도 정보입니다.** 어제 진단은 횡방향 얀의 균열대가
   꺼져 있어서라고 지목했고, M6는 그걸 켰습니다. 그래도 안 밀리면 **원인이
   균열대가 아니라는 뜻**이라 다음 수를 바꿉니다.

---

# 파일 목록

| 파일 | 용도 | 실행기 |
|---|---|---|
| `RVE_COND_P00_k8.inp` 외 3 | 열전도 덱 (UMAT 불필요) | `abaqus job=` |
| `M6_c26k_RT23/T500/T1000.inp` | 인장 덱 | `abaqus job= ... user=` |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT (**M6 전용, 필수**) | — |
| `extract_kbar.py` | $\bar k$ 계산·판정 | **`abaqus python`** |
| `extract_ss_curve.py` | 응력–변형률 CSV | **`abaqus python`** |
| `damage_census.py` | 손상·**ATEFF** census | **`abaqus python`** |
| `driver_audit.py` | 드라이버 반력 감사 | **`abaqus python`** |
| `m6_verdict.py` | **M6 최종 판정** | `python` |
| `plot_compare.py` | 곡선 그림 | `python` |
