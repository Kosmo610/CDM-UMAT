# LTH_DMGFIX_0815_2345 — 손상 상한 판정을 닫는 후처리 (해석 불요)

**해석은 다시 돌리지 않습니다. 이미 있는 `.odb`를 다시 읽기만 합니다.**
잡 하나당 몇 초입니다.

## 왜 다시 읽는가

`damage_map.py`의 부피 구간 최상단이 손상 상한 **0.90 위에 정확히** 놓여
있었습니다. 손상은 상한에 **접근할 뿐 도달하지 않으므로** 그 칸은 구조적으로
절대 켜지지 않았고, 모든 실행이 모든 상에서 `volfrac_damg_ge_0.90 = 0`을
보고했습니다. 그 값이 **강도를 인용해도 되는지 판정하는 데 필요한 유일한 수**
입니다.

같이 고친 것:
- 손상 상한을 `retune_deck.D_DMAX`에서 **읽어 옵니다** (0.99로 적혀 있었습니다).
- 상한을 **성분 값**으로 셉니다. 얀의 `DY1`은 인장·압축을 합친 값이라
  0.976이 나와도 어느 성분도 상한에 닿지 않았을 수 있습니다.

## 덮어쓸 파일

작업 폴더의 `damage_map.py`를 이 폴더의 것으로 **교체**하세요.
`damage_ceiling.py`는 새 파일입니다.

## ① ODB 다시 읽기 — 세 잡, 각각 몇 초

    abaqus python damage_map.py LTH_M6_RT23.odb
    abaqus python damage_map.py LTH_M6_T500.odb
    abaqus python damage_map.py LTH_M6_T1000.odb

## ② 판정

    python damage_ceiling.py LTH_M6_RT23_damage_map.csv LTH_M6_T500_damage_map.csv LTH_M6_T1000_damage_map.csv

## 채팅에 올릴 파일

- `damage_ceiling_summary.csv`  ← **이것이 판정입니다**
- `LTH_M6_RT23_damage_map.csv`
- `LTH_M6_T500_damage_map.csv`
- `LTH_M6_T1000_damage_map.csv`
