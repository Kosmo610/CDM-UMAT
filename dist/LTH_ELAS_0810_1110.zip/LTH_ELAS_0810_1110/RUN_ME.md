# LTH_ELAS — 거시 카드의 탄성·팽창을 실물로 (잡 6개, 전부 병렬, ~30분)

압축을 `E:\LTH\` 에 풀면 `E:\LTH\LTH_ELAS_0810_1110\` 이 됩니다.

```
E:
cd \LTH\LTH_ELAS_0810_1110
```

**폴더 이름을 바꾸셨으면 `cd` 줄만 고치세요.** 나머지는 전부 상대 경로입니다.

---

## 왜 이것이 지금인가

거시 재료카드가 아직 `PLACEHOLDER` 입니다. `homogenize.py` 가 **한 번도 돌아간
적이 없어서**입니다 — 저장소에 `_ELAS_`·`_CTE_` odb가 하나도 없습니다.

이 6잡이 그 절반을 실물로 바꿉니다:

| 얻는 것 | 무엇 |
|---|---|
| $\bar C(T)$ | 유효 강성 9개 — $E_1 E_2 E_3\ \nu_{12} \nu_{13} \nu_{23}\ G_{12} G_{13} G_{23}$ |
| $\bar\alpha(T)$ | 유효 열팽창 3개 |

**23 / 500 / 1000 °C 세 온도**이므로 카드의 $f(T)$ 열까지 채워집니다.

**손상이 꺼져 있는 선형 프로브라 M6 보정 결과에 영향받지 않습니다.** 즉 M6가
몇 회차를 더 가더라도 **이 6잡을 다시 돌릴 일은 없습니다.** 30분에 이만한
것이 없어서 대기열 앞으로 당겼습니다.

## 카드는 공극률 32.4 % 쪽으로 세웠습니다

열전도 결과가 요구한 것은 23.8~25.4 % 였고 강성이 요구하는 것은 32.4 % 입니다.
**32.4 %(기지 $E$ = 213 110 MPa)를 썼습니다.** 이유는 세 가지입니다.

1. **보정 계보와 같은 카드여야 합니다.** M6가 213 110 위에서 보정되는데
   $\bar C$ 를 350 GPa 카드에서 재면 **다른 RVE의 물성**이 되고, 그 어긋남을
   잡아 줄 검사가 하류에 없습니다.
2. **열전도 쪽 오차는 안전한 방향입니다.** 32.4 %면 $\bar k_3$ 가 실측보다
   13.4 % 낮고, $\bar k$ 가 낮으면 $Bi$ 가 커져 **급랭이 더 가혹**해집니다.
3. **TRS 비교에는 공통모드로 들어갑니다.** A/B/C 세 케이스가 같은 $\bar k$ 를
   쓰므로 논문의 중심 주장은 이 13.4 %에 둔감합니다.

**한계로 명시할 것**: 스칼라 공극률 하나로 강성과 열전도를 동시에 못 맞춥니다.

---

# ① 실행 — **6잡 전부 병렬.** 창 6개

**UMAT이 필요합니다**(손상은 꺼져 있지만 구성모델은 UMAT이 계산합니다).

창 1
```
abaqus job=LTH_RVE_ELAS_T23 input=LTH_RVE_ELAS_T23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```
창 2
```
abaqus job=LTH_RVE_ELAS_T500 input=LTH_RVE_ELAS_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```
창 3
```
abaqus job=LTH_RVE_ELAS_T1000 input=LTH_RVE_ELAS_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```
창 4
```
abaqus job=LTH_RVE_CTE_T23 input=LTH_RVE_CTE_T23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```
창 5
```
abaqus job=LTH_RVE_CTE_T500 input=LTH_RVE_CTE_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```
창 6
```
abaqus job=LTH_RVE_CTE_T1000 input=LTH_RVE_CTE_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=4 memory="30gb"
```

- 합계 **24코어 / 180 GB** — 32코어·256 GB 안입니다.
- 토큰은 잡당 `int(5·4^0.422)` = **8개**, 6잡 **48개**.
  **모자라다는 메시지가 뜨면 `cpus=2`로 낮추세요**(잡당 6개, 합계 36).
  **잡 수는 줄이지 마세요** — 어차피 여섯 개 다 필요합니다.
- `CSiC_RVE_0135.ori` 가 **같은 폴더에 있어야 합니다.** 덱이 이름으로
  참조하므로 없으면 즉시 죽습니다. (묶음에 넣어 뒀습니다)

# ② 완료 후 — **6잡이 다 끝난 뒤 한 번**

```
abaqus python homogenize.py LTH_RVE --temps 23 500 1000
```

→ **`LTH_RVE_homogenised.csv`** ← **이 파일을 올려 주세요**

같이 생기는 `LTH_RVE_macro_card.inp` 는 **아직 반쪽입니다** — 강도와 $\bar G_f$
슬롯이 0입니다(강도 덱을 아직 안 돌렸으니 당연합니다). **그 카드를 거시 덱에
넣지 마세요.** 이번에 받을 것은 CSV의 $\bar C$·$\bar\alpha$ 입니다.
콘솔에 `(no ..._STR_... -- ... left at 0)` 이 여러 줄 뜨는 것이 정상입니다.

## ★ 첫 실행에서 눈으로 확인할 것 두 가지

콘솔에 이 두 줄이 나옵니다. **그대로 알려 주세요.**

```
Cbar diagonal (MPa): ...
Cbar asymmetry ...
```

1. **2D 평직이면 $C_{11} \approx C_{22} \gg C_{33}$ 이어야 합니다.**
   날실과 씨실이 대칭이므로 앞 둘이 같아야 하고, 두께 방향은 확연히 작아야
   합니다. **이것이 어긋나면 재료가 아니라 주기경계조건이나 드라이버 매핑이
   틀린 것입니다.**
2. **전단 대각 3개가 뚜렷이 구분되는지.** 순서가 예상과 다르면 TexGen 드라이버
   순서가 반대라는 뜻이고, 그때는 `--shear-order xy-yz-xz` 로 **후처리만**
   다시 돌리면 됩니다(해석 재실행 불필요).

`Cbar asymmetry` 는 이산화 품질 지표입니다. 값만 알려 주시면 됩니다.

---

# 파일 목록

| 파일 | 무엇 |
|---|---|
| `LTH_RVE_ELAS_T23/500/1000.inp` | 단위 거시변형 6모드 → $\bar C(T)$ |
| `LTH_RVE_CTE_T23/500/1000.inp` | 구속 2스텝 차분 → $\bar\alpha(T)$ |
| `CSiC_RVE_0135.ori` | **TexGen 섬유방향. 덱이 이름으로 부릅니다 — 반드시 같은 폴더** |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT |
| `homogenize.py` | 판독 — `abaqus python` |

> `.ori` 는 메시와 한 몸입니다. 이 묶음의 `.ori` 는 이 덱들의 메시
> (`CSiC_RVE_0135`, 26 452 C3D4)에 맞춰진 것이라 **다른 메시에 쓰면 에러 없이
> 섬유 방향이 틀린 채로 수렴합니다.** 다른 폴더의 `.ori` 를 섞지 마세요.
