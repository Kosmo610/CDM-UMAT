# M4 — 0730_1623

**폴더 안 나눴습니다. 전부 이 폴더 하나에 평평하게 있습니다.**

---

## 먼저 읽어주세요 — M3는 실패가 아닙니다

M3에서 **z600이 완주**했고, 나머지 셋도 M1FIX보다 훨씬 멀리 갔습니다.
그리고 **재가열 문제는 완전히 해결됐습니다.**

| 재가열 스텝 (23 → T °C) | 증분 | 실패 시도 | 증분 크기 중앙값 |
|---|---|---|---|
| M1FIX (T500) | 12888 시도 | **2888** | 9.5e-08 (최대의 1/26000) |
| **M3 (T500)** | **404** | **0** | **2.5e-03 = 허용 최대** |
| **M3 (T1000)** | **403** | **0** | **2.5e-03 = 허용 최대** |

증분당 평형반복 2.3회 — 손상이 없는 선형 문제와 사실상 같습니다.
**`sign(I1)` 스무딩이 원인을 정확히 짚었다는 증거이고, 이건 논문에 들어갈 결과입니다.**

---

## ★ 재실행보다 먼저 할 일 — 이미 있는 .odb에서 뽑기

**M3 네 잡 중 셋은 이미 피크(최대 응력)를 지났습니다.** 죽은 잡의 `.odb`도
수렴한 증분은 온전합니다. **M4를 돌리기 전에 이것부터 하세요. 공짜입니다.**

| 잡 | 인장 스텝 하중 이력 | 판정 |
|---|---|---|
| `z600` | 0.168 → **0.174** → 0.172 (76 %에서 피크) | **피크 통과 + 완주** |
| `T500` | 0.129 → **0.163** → 0.159 (60 %에서 피크) | **피크 통과** |
| `RT23` | 0.242 → 0.143, 계속 평탄/하강 | **상승 구간 자체가 없음** |
| `T1000` | 0.060 → **0.149**, 끝까지 상승 | 피크 미도달 (유일) |

`RT23`에 상승 구간이 없는 것 자체가 물리 결과입니다 — 무응력 온도 1050 °C에서는
기지가 이미 TRS로 갈라져 있어서 인장이 시작되자마자 피크입니다. 수치 설정이 완전히
같은 `z600`(600 °C)에는 정상적인 상승 구간이 있습니다.

### M3 .odb에서 뽑는 명령 — **`abaqus python`**

```
abaqus python extract_ss_curve.py M3_c26k_RT23_z600.odb
```
```
abaqus python extract_ss_curve.py M3_c26k_T500.odb
```
```
abaqus python extract_ss_curve.py M3_c26k_RT23.odb
```
```
abaqus python extract_ss_curve.py M3_c26k_T1000.odb
```

### ★ 그리고 이것 — M4의 전제를 검증하는 명령입니다

```
abaqus python driver_audit.py M3_c26k_RT23_z600.odb
```
```
abaqus python driver_audit.py M3_c26k_T500.odb
```

**이 결과를 꼭 보내주세요.** M4는 "매크로 전단변형률 3개를 0으로 묶어도 물리적으로
공짜다"라는 **가정** 위에 서 있습니다. 균형 직교 2D 직물을 주축으로 당기면 대칭성상
0이어야 하지만, TexGen 메시가 정확히 대칭은 아니므로 **재보는 수밖에 없습니다.**

- 매크로 전단응력이 `sigma_xx`의 **1 % 미만** → 묶어도 공짜. M4 그대로 진행.
- **1 % 이상** → 묶는 것이 실제 모델링 변경입니다. 논문에 명시해야 하고,
  저에게 알려주시면 다른 방법으로 갑니다.

`driver_audit.py`는 **ALLSD/ALLIE도 같이 찍습니다** — CAE 안 열어도 됩니다.

---

## M3에서 남은 문제 — 재료가 아니라 경계조건입니다

`.msg`를 반복 단위로 읽으니, 잔차가 **하중이 걸린 드라이버 위에 있는 경우가 거의
없었습니다.** 절점 5681–5686은 재료 절점이 아니라 주기경계조건 **더미 절점**입니다.

| 절점 | 드라이버 | |
|---|---|---|
| 5681 | `eps_xx` | ← **유일하게 하중이 걸린 것** |
| 5682·5683 | `eps_yy`·`eps_zz` | 자유 (포아송) |
| 5684·5685·5686 | `eps_xy`·`eps_xz`·`eps_yz` | 자유 (전단) |

| 잡 | 매크로 드라이버 위 잔차 | 그중 **하중** 드라이버 |
|---|---|---|
| RT23 | **63.4 %** | 3 회 (0.03 %) |
| T500 | **69.8 %** | 4.3 % |
| T1000 | **84.5 %** | 7.6 % |
| z600 | **75.1 %** | 2 회 (0.08 %) |

드라이버 반력은 $R = \sigma \times V_{RVE}$ (V=5.390 mm³)이므로 **그 잔차가 곧
매크로 응력 오차**입니다:

| 잡 | 마지막 잔차 | **응력으로 환산** |
|---|---|---|
| RT23 | 3.959e-03 N·mm | **0.00073 MPa** |
| T1000 | 4.310e-02 N·mm | **0.0080 MPa** |
| T500 | 8.249e-02 N·mm | **0.015 MPa** |

Abaqus는 이걸 전역 평균 절점력의 0.5 %, 즉 **0.00014 MPa**와 대조합니다.
측정하려는 축응력은 100–200 MPa입니다. **다섯 자릿수 더 엄격한 판정을
"응력이 0이어야 하는" 자유 드라이버에 요구하고 있었습니다.**

증분 크기 문제가 아닌 것도 확인했습니다 — T1000은 `dt`를 8배 줄여도 잔차가
그대로였고, RT23은 Newton 보정이 **1e-19 ~ 1e-22**(기계 정밀도의 0)인데 잔차가
남아 있었습니다.

그리고 RT23에서만 나온 특이점 36개는 전부 드라이버 위였습니다:
```
NUMERICAL SINGULARITY WHEN PROCESSING NODE 5684  RATIO = 25.7164E+09
```
5684 = `eps_xy`. 피벗 비 2.6e+10 — 매크로 전단강성이 사실상 0이 된 것이고,
손상대가 RVE를 관통해 두 덩어리가 거의 공짜로 미끄러진다는 뜻입니다.

> **제 이전 진단 정정:** Round 3에서 "자유도 3(두께 방향)이 공통 원인"이라고 했는데
> **틀렸습니다.** 5681–5686을 메시 절점으로 착각했습니다. 드라이버를 분리하고 다시
> 세면 메시 절점의 자유도 분포는 1:2794 / 2:2106 / 3:1493으로 두께 방향 우세가
> 없습니다. 재가열 진단과 그 해법은 맞았지만, 근거로 든 숫자는 잘못 읽은 것이었습니다.

---

## M4에서 바뀐 것 — 딱 두 가지

M3 덱과의 diff가 **정확히 이 둘뿐**입니다 (메시·물성 블록은 바이트 단위로 동일).

1. **전단 드라이버 3개를 0으로 구속** — 모든 스텝에 반복 기재
   ```
   *Boundary
   ConstraintsDriver3, 1, 1, 0.0     (eps_xy)
   ConstraintsDriver4, 1, 1, 0.0     (eps_xz)
   ConstraintsDriver5, 1, 1, 0.0     (eps_yz)
   ```
   죽는 순간의 반복이 T1000은 12개 중 11개, RT23은 14개 중 13개가 전단
   드라이버였습니다. **`eps_yy`·`eps_zz`는 그대로 자유입니다** — 포아송을 막으면
   구속시험이 되어 강도가 부풀려집니다.

2. **힘 잔차 판정 완화** 0.005 → 0.02
   ```
   *Controls, parameters=field, field=force
    0.02,
   ```
   0.02면 허용 오차가 매크로 응력 0.00056 MPa — 축응력보다 여전히 네 자릿수
   아래입니다. **이건 판단이 들어간 설정이라 논문에 그대로 적습니다.**

나머지는 M3와 동일: HSMO 0.1 · djump 0.10 · inc 2000 · dmax 0.90 · eta 0.05 ·
stabilize 2e-04 · 변위판정 1.0 · I_R=16 · I_A=8.

---

## ① 실행 명령 — 창 4개 병렬, **UMAT은 V3_0**

```
abaqus job=M4_c26k_RT23 input=M4_c26k_RT23.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```
```
abaqus job=M4_c26k_RT23_z600 input=M4_c26k_RT23_z600.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```
```
abaqus job=M4_c26k_T500 input=M4_c26k_T500.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```
```
abaqus job=M4_c26k_T1000 input=M4_c26k_T1000.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=8 memory="55gb"
```

> **`user=`가 V3_0입니다.** V1_0을 쓰면 즉시 죽습니다 (카드가 22 → 25 슬롯).
>
> M3 기준으로 잡당 0.6–3.5 시간입니다. 증분 예산 2000이라 최악이어도 몇 시간입니다.

**급하시면 `T1000` 하나만 먼저 돌리셔도 됩니다** — 나머지 셋은 M3 `.odb`에 이미
피크가 들어 있어서, M4는 확인 사살에 가깝습니다.

---

## ② 해석 완료 후 명령

### (a) 응력–변형률 — **`abaqus python`**
```
abaqus python extract_ss_curve.py M4_c26k_RT23.odb
```
```
abaqus python extract_ss_curve.py M4_c26k_RT23_z600.odb
```
```
abaqus python extract_ss_curve.py M4_c26k_T500.odb
```
```
abaqus python extract_ss_curve.py M4_c26k_T1000.odb
```

### (b) 드라이버 + 에너지 감사 — **`abaqus python`**
```
abaqus python driver_audit.py M4_c26k_RT23.odb
```
```
abaqus python driver_audit.py M4_c26k_RT23_z600.odb
```
```
abaqus python driver_audit.py M4_c26k_T500.odb
```
```
abaqus python driver_audit.py M4_c26k_T1000.odb
```
ALLSD/ALLIE가 여기서 같이 나옵니다. **5 % 미만이어야 합니다.**

### (c) 손상 분포 — **`abaqus python`**
```
abaqus python damage_census.py M4_c26k_RT23.odb
```
```
abaqus python damage_census.py M4_c26k_RT23_z600.odb
```

### (d) 그림 — **`python3`** (일반 파이썬, `abaqus python` 아님)
```
python3 plot_compare.py M4_c26k_RT23_ss.csv M4_c26k_T500_ss.csv M4_c26k_T1000_ss.csv
```

---

## 보내주실 것

**M3 .odb에서 (재실행 전에, 지금 바로):**
1. `extract_ss_curve.py` 네 개의 `ULTIMATE STRESS` / `initial modulus` 줄
2. **`driver_audit.py`의 전단 판정 줄** ← M4의 전제입니다. 제일 중요합니다.

**M4에서:**
3. 네 잡의 `.sta` 마지막 3줄
4. `extract_ss_curve.py`의 `ULTIMATE STRESS` / `initial modulus`
5. `driver_audit.py`의 ALLSD/ALLIE
6. 각 잡의 벽시계 시간

목표는 Zhang Table 3 — **128.45 / 179.42 / 199.15 MPa** (RT23 / 500 / 1000 °C)
입니다. M3의 하중 이력이 이미 `RT23 < T500` 순서를 맞게 보여주고 있습니다.
