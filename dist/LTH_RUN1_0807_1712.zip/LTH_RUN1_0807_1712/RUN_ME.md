# LTH_RUN1 — 지금 돌릴 수 있는 전부 (잡 7개)

**작업 폴더는 `E:\LTH` 로 합의했습니다.** 압축을 풀어 **파일들이
`E:\LTH\파일명` 이 되도록** 두세요 (하위 폴더 없이 평평하게).

```
E:\LTH\LTH_COND_P00.inp
E:\LTH\LTH_CJ1.inp
E:\LTH\UMAT_CSIC_THERMSHOCK_V3_0.for
...
```

모든 명령은 그 폴더에서 실행합니다. 명령창을 열면 먼저:

```
E:
cd \LTH
```

---

## 무엇을 왜 돌리는가

| 묶음 | 잡 | 답하는 질문 |
|---|---|---|
| **A. 열전도 (4잡)** | `LTH_COND_*` | **공극률이 몇 %인가.** 측정 $\bar k_3$ = 6.29 W/(m·K)를 만드는 공극률을 역산해, 강성이 요구하는 32.4 %와 대조 |
| **B. 사이클점프 (3잡)** | `LTH_CJHEAT`, `LTH_CJ1`, `LTH_CJ5` | **한 증분으로 5사이클을 대표해도 되는가.** 명시적(43스텝) 대 5배점프(11스텝)의 E(N) 차이 측정 |

두 묶음은 **서로 완전히 독립**입니다.

---

# ① 해석 실행 명령

## ★ 1파: 5잡 동시 — **전부 병렬 가능**

**Abaqus Command 창을 5개 열고 각 창에 하나씩** 넣으세요.
열전도 4잡은 **UMAT이 필요 없습니다**(선형 정상상태). 각 수 분이면 끝납니다.

창 1:
```
abaqus job=LTH_COND_P00 input=LTH_COND_P00.inp double interactive cpus=2 memory="20gb"
```

창 2:
```
abaqus job=LTH_COND_P05 input=LTH_COND_P05.inp double interactive cpus=2 memory="20gb"
```

창 3:
```
abaqus job=LTH_COND_P32 input=LTH_COND_P32.inp double interactive cpus=2 memory="20gb"
```

창 4:
```
abaqus job=LTH_COND_P32K60 input=LTH_COND_P32K60.inp double interactive cpus=2 memory="20gb"
```

창 5:
```
abaqus job=LTH_CJHEAT input=LTH_CJHEAT.inp double interactive cpus=2 memory="8gb"
```

- 합계 **10코어 / 88 GB** — 32코어·256 GB에 여유가 큽니다.
- 라이선스 토큰은 잡당 `int(5·2^0.422)` = **6개**, 5잡 **30개**.
  **모자라다는 메시지가 뜨면 `cpus=1`로 낮추세요**(잡당 5개, 합계 25).
  잡 수를 줄이지는 마세요 — 어차피 다 필요합니다.

## 2파: 2잡 동시 — **병렬 가능. 단 창 5(LTH_CJHEAT)가 끝난 뒤**

역학 잡이 열 ODB를 읽으므로 **이것만 순서가 있습니다.**
1파의 열전도 4잡과는 아무 관계 없으니, 그쪽이 아직 돌고 있어도 시작해도 됩니다.

창 A:
```
abaqus job=LTH_CJ1 input=LTH_CJ1.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="40gb"
```

창 B:
```
abaqus job=LTH_CJ5 input=LTH_CJ5.inp user=UMAT_CSIC_THERMSHOCK_V3_0.for double interactive cpus=6 memory="40gb"
```

- 메시가 720요소로 작아 코어를 더 줘도 빨라지지 않습니다.
- **CJ5(11스텝)가 먼저 끝나고 CJ1(43스텝)이 더 걸립니다.**

---

# ② 해석 완료 후 명령

`.odb`만 나옵니다. **CSV·판정은 아래를 돌려야 나옵니다.**

## A. 열전도 4잡이 다 끝나면 (ODB를 읽으므로 **`abaqus python`**)

```
abaqus python extract_kbar.py LTH_COND_P00.odb LTH_COND_P05.odb LTH_COND_P32.odb LTH_COND_P32K60.odb
```

**판정이 그대로 출력됩니다** — 측정 6.29를 만드는 공극률과, 그것이
강성이 요구하는 32.4 %와 **양립하는지(CONSISTENT) 아닌지(INCOMPATIBLE)**.

## B. 사이클점프 — 잡 하나 끝날 때마다 바로 돌려도 됩니다

```
abaqus python extract_probe.py LTH_CJ1.odb
abaqus python extract_probe.py LTH_CJ5.odb
```

→ `LTH_CJ1_EN.csv`, `LTH_CJ5_EN.csv`

둘 다 나오면 비교·판정 (**일반 `python`** — matplotlib/CSV만 씁니다):

```
python compare_cyclejump.py LTH_CJ1_EN.csv LTH_CJ5_EN.csv
```

판정:
- **< 1 %** 무시 가능 → 고정 점프 확정
- **1–3 %** 허용 → 모든 E(N) 결과 옆에 이 숫자 병기
- **> 3 %** 너무 거침 → 점프 절반으로 줄여 재실행

> 문턱 근거는 refs/[10] Table 1의 실측 모듈러스 산포(1.40–4.05 %)입니다.
> 그리고 **이 오차는 손상증분 허용치 `max_djump = 0.10`에서 잰 값**이라
> refs/[57] 예시(0.01)보다 10배 느슨합니다 — 스크립트가 이 단서를
> 결과와 함께 자동 출력합니다.

- 후처리에는 `cpus`·`memory`를 **붙이지 않습니다** (단일 스레드, 수 초).

---

# 겸사 확인 (공짜, 알려주세요)

`LTH_CJ1_EN.csv`의 **`twmax_prev_block` 열이 900** 이면, 사이클 블록이 정말
최고온도(T_hi)에 앉아 있었다는 뜻입니다 — 이번에 UMAT에 새로 넣은
**사이클 심각도 창(SDV 29)** 이 실제 해석에서 작동했다는 첫 실물 증거입니다.
**900이 아니면 그 값을 그대로 알려주세요.**

---

# 파일 목록 (전부 `E:\LTH\` 에 평평하게)

| 파일 | 무엇 | UMAT |
|---|---|---|
| `LTH_COND_P00.inp` | 기지 공극률 **0 %** | 불필요 |
| `LTH_COND_P05.inp` | 기지 공극률 **4.5 %** | 불필요 |
| `LTH_COND_P32.inp` | 기지 공극률 **32.4 %** | 불필요 |
| `LTH_COND_P32K60.inp` | 32.4 % + **얀 종방향 k=50.2** (민감도) | 불필요 |
| `LTH_CJHEAT.inp` | 열전달 — **CJ1·CJ5가 공유** | 불필요 |
| `LTH_CJ1.inp` | 명시적 20사이클 (43스텝) | **필요** |
| `LTH_CJ5.inp` | 5배 점프 (11스텝) | **필요** |
| `UMAT_CSIC_THERMSHOCK_V3_0.for` | UMAT (T_max 창 포함) | — |
| `extract_kbar.py` | 공극률 판정 — `abaqus python` | — |
| `extract_probe.py` | E(N) 추출 — `abaqus python` | — |
| `compare_cyclejump.py` | 점프 오차 판정 — 일반 `python` | — |

> `LTH_CJ1`·`LTH_CJ5` 카드는 **선행검증 전용으로 RTH를 0.30 → 0.10** 으로
> 낮춰 두었습니다(덱 안에 주석). d_cyc가 확실히 쌓이게 하려는 것이며
> **보정값이 아닙니다.**

> **M6(유효물성) 3잡은 일부러 뺐습니다.** 공극률이 확정돼야 카드가 정해지고,
> 그게 바로 묶음 A가 답하는 것입니다. 먼저 돌리면 두 번 돌리게 됩니다.
