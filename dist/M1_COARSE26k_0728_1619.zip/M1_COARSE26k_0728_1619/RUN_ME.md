# M1 (거친 메시) — Zhang 2022 재현 3케이스

**패키지 생성: 2026-07-28 16:19 KST** · **대상: 32코어 / 256 GB**
**메시: `CSiC_RVE_0135.inp` (TexGen 0.135 mm), 26,452 C3D4 / 5,686 노드**

---

## 🔴 먼저 — `.ori` 파일을 넣어야 합니다

`.inp` 3개가 모두 아래 파일을 참조합니다:

```
Input=CSiC_RVE_0135.ori
```

메시를 만드실 때 같이 나온 파일입니다. **`abaqus/` 폴더 안, `.inp`와 같은 위치**에
**파일명 그대로** 복사해 주세요. 이름이 다르면 실패합니다.

```
dir abaqus\CSiC_RVE_0135.ori
```

> 이 `.ori`를 저에게 올려주시면 다음부터는 **덱 안에 내장(`--inline-ori`)** 해서
> 외부 파일 없는 자기완결 패키지로 드리겠습니다. 그러면 이 단계가 영원히 사라집니다.

---

## 실행 — 세 잡은 서로 완전히 독립입니다

> ### **Abaqus Command 창을 3개 열고, 각각에 하나씩 입력하세요.**

**1번 창**
```
abaqus job=Job-c26k-RT23 input=abaqus/ZHANG2022_c26k_RT23.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

**2번 창**
```
abaqus job=Job-c26k-T500 input=abaqus/ZHANG2022_c26k_T500.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

**3번 창**
```
abaqus job=Job-c26k-T1000 input=abaqus/ZHANG2022_c26k_T1000.inp user=src/UMAT_CSIC_RVE_ZHANG2022_V1_0.for double interactive cpus=8 memory="30gb"
```

### 왜 17만 요소 때(`cpus=10, 70gb`)보다 낮은가

이 모델은 **26k 요소 / 약 17k 자유도**로 작습니다. 코어를 더 준다고 빨라지지 않고
병렬 오버헤드만 늘어납니다. 메모리도 30 GB면 충분히 in-core로 풉니다.
3 × 8 = 24코어, 3 × 30 = 90 GB — 여유가 많으니 **다른 작업과 같이 돌리셔도 됩니다.**

`double`은 **필수**입니다. 라이선스 토큰이 부족하면 `cpus=4`로 낮추세요
(잡 개수는 줄이지 마세요).

---

## 끝난 뒤 — 후처리

```
abaqus python postprocess/extract_ss_curve.py Job-c26k-RT23.odb
abaqus python postprocess/extract_ss_curve.py Job-c26k-T500.odb
abaqus python postprocess/extract_ss_curve.py Job-c26k-T1000.odb
```

```
python postprocess/plot_compare.py Job-c26k-RT23_ss.csv Job-c26k-T500_ss.csv Job-c26k-T1000_ss.csv
```

---

## 제가 미리 확인해 둔 것 (다시 안 하셔도 됩니다)

메시를 받아서 솔버 없이 검증한 내용입니다.

| 항목 | 결과 |
|---|---|
| 요소/노드 | 26,452 C3D4 / 5,686 |
| RVE 치수 | **3.5 × 3.5 × 0.44 mm**, V = **5.39 mm³** |
| 메시 충전율 | **100 %** (공극 없음) → `V_RVE`가 정확히 5.39 mm³ |
| ElSet | Matrix + **Yarn0~3** (4개) — 정상 인식 |
| 주기경계조건 | `*Equation` **57식** 보존 |
| 드라이버 | ConstraintsDriver0~5, 노드 5681–5686 정의됨 |
| **섬유체적비** | 얀 체적분율 0.4982 × Vf_yarn 0.79194 = **39.46 %** |

**섬유체적비가 핵심 확인입니다.** 검증된 카드가 39.6 %, Zhang 2022이 "약 40 %"이므로
**상대차 0.35 %** — 이 거친 메시는 미세 메시와 **같은 복합재**를 나타냅니다.
즉 결과 차이가 나면 그건 재료가 달라서가 아니라 순수하게 메시 해상도 때문입니다.
(메시 수렴성 검증할 때 이 구분이 중요합니다)

### ★ 전단 순서 확정 — 나중 작업 하나가 없어졌습니다

TexGen이 파일 안에 직접 적어 두었습니다 (33852행):

```
*** ConstraintsDriver0 = e_x     ConstraintsDriver3 = e_xy
*** ConstraintsDriver1 = e_y     ConstraintsDriver4 = e_xz
*** ConstraintsDriver2 = e_z     ConstraintsDriver5 = e_yz
```

→ `homogenize.py --shear-order xy-xz-yz` (기본값). **첫 실행에서 확인할 필요 없습니다.**

또 PBC 식이 `FaceA − FaceB − 3.5·U_driver0 = 0` 이고 Lx = 3.5 mm이므로
**`U(driver, dof1) = 거시 변형률` 그대로**입니다. 후처리 스크립트의 가정과 일치합니다.

---

## 목표값과 다음 단계

| 온도 | Zhang Table 3 |
|---|---|
| 23 °C | **128.45 MPa** |
| 500 °C | **179.42 MPa** |
| 1000 °C | **199.15 MPa** |

**첫 실행에서 안 맞는 게 정상입니다.** 논문 미공개 파라미터 보정이 필요하고,
거친 메시를 쓰는 이유가 바로 이 **보정 반복을 빠르게** 하기 위해서입니다.
절차는 `CALIBRATION_GUIDE.md`.

## 보내주실 것

`.odb`는 보내지 마시고:

1. **`*_ss.csv` 3개**
2. **`.sta` 3개** — 수렴 이력
3. `.msg`에 경고/에러가 있으면 그 부분
4. **각 잡 소요 시간** — 이후 RVE 가상시험(모드 8개 × 온도 3개)의 규모를 잡는 데 씁니다

시간만 알면 다음 매트릭스를 몇 개씩 나눠 돌릴지 정확히 계산해 드릴 수 있습니다.
